-- ==============================================================================
-- DigiSeba BD - Production Database Schema (UTF8MB4)
-- Target Hosting: InfinityFree Free Hosting / cPanel MySQL 5.7+ / 8.0+
-- Security: Prepared statements, InnoDB transactions, Foreign keys, Immutable audit
-- ==============================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- -----------------------------------------------------------------------------
-- 1. Roles Table (RBAC)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `roles` (
  `id` VARCHAR(50) PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `description` VARCHAR(255) NULL,
  `is_system` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- 2. Permissions Table (Granular Actions)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `permissions` (
  `id` VARCHAR(50) PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `slug` VARCHAR(100) NOT NULL UNIQUE,
  `module` VARCHAR(50) NOT NULL,
  `description` VARCHAR(255) NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- 3. Role Permissions Pivot Table
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `role_permissions` (
  `role_id` VARCHAR(50) NOT NULL,
  `permission_id` VARCHAR(50) NOT NULL,
  PRIMARY KEY (`role_id`, `permission_id`),
  CONSTRAINT `fk_rp_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rp_perm` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- 4. Users Table (Customers, Staff & Administrators)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `users` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `phone` VARCHAR(20) NOT NULL UNIQUE,
  `email` VARCHAR(150) NOT NULL UNIQUE,
  `password_hash` VARCHAR(255) NOT NULL,
  `role` ENUM('customer', 'admin', 'staff') NOT NULL DEFAULT 'customer',
  `role_id` VARCHAR(50) NULL,
  `status` ENUM('active', 'suspended') NOT NULL DEFAULT 'active',
  `avatar` VARCHAR(255) NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_phone` (`phone`),
  INDEX `idx_email` (`email`),
  INDEX `idx_role` (`role`),
  CONSTRAINT `fk_user_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- 5. Customer Wallets Table (Atomic Balance)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `wallets` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT UNSIGNED NOT NULL UNIQUE,
  `balance` DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `fk_wallet_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- 6. Immutable Wallet Transaction Ledger (Financial Audit Trail)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `wallet_ledger` (
  `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT UNSIGNED NOT NULL,
  `amount` DECIMAL(12, 2) NOT NULL,
  `type` ENUM('credit', 'debit') NOT NULL,
  `category` ENUM('recharge', 'order', 'refund', 'adjustment') NOT NULL,
  `reference_id` VARCHAR(100) NOT NULL,
  `description` VARCHAR(255) NOT NULL,
  `balance_after` DECIMAL(12, 2) NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_ledger_user` (`user_id`),
  INDEX `idx_ledger_ref` (`reference_id`),
  INDEX `idx_ledger_created` (`created_at`),
  CONSTRAINT `fk_ledger_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- 7. Manual Recharge Requests (Prevents duplicate TrxID & double approval)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `recharge_requests` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT UNSIGNED NOT NULL,
  `method` ENUM('bKash', 'Nagad', 'Rocket', 'Bank') NOT NULL,
  `amount` DECIMAL(12, 2) NOT NULL,
  `sender_number` VARCHAR(30) NOT NULL,
  `trx_id` VARCHAR(100) NOT NULL UNIQUE,
  `proof_screenshot` VARCHAR(255) NULL,
  `status` ENUM('pending', 'approved', 'rejected') NOT NULL DEFAULT 'pending',
  `rejection_reason` VARCHAR(255) NULL,
  `verified_by_admin_id` INT UNSIGNED NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `approved_at` DATETIME NULL,
  INDEX `idx_rch_trx` (`trx_id`),
  INDEX `idx_rch_status` (`status`),
  CONSTRAINT `fk_recharge_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- 8. Service Categories Table
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `service_categories` (
  `id` VARCHAR(50) PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `bangla_name` VARCHAR(150) NOT NULL,
  `icon_name` VARCHAR(50) NOT NULL DEFAULT 'Layers',
  `description` TEXT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- 9. Services Table
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `services` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `service_code` VARCHAR(50) NOT NULL UNIQUE,
  `name` VARCHAR(150) NOT NULL,
  `bangla_name` VARCHAR(150) NOT NULL,
  `category_id` VARCHAR(50) NOT NULL,
  `price` DECIMAL(10, 2) NOT NULL,
  `estimated_delivery_time` VARCHAR(100) NOT NULL DEFAULT '১৫-৩০ মিনিট',
  `description` TEXT NULL,
  `instructions` TEXT NULL,
  `icon` VARCHAR(50) NOT NULL DEFAULT 'FileText',
  `status` ENUM('active', 'inactive', 'archived') NOT NULL DEFAULT 'active',
  `order_count` INT UNSIGNED NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_srv_status` (`status`),
  INDEX `idx_srv_category` (`category_id`),
  CONSTRAINT `fk_srv_category` FOREIGN KEY (`category_id`) REFERENCES `service_categories` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- 10. Dynamic Service Form Fields Table
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `service_form_fields` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `service_id` INT UNSIGNED NOT NULL,
  `field_key` VARCHAR(50) NOT NULL,
  `label` VARCHAR(100) NOT NULL,
  `bangla_label` VARCHAR(150) NOT NULL,
  `field_type` ENUM('text','number','tel','email','date','select','radio','checkbox','textarea','file') NOT NULL DEFAULT 'text',
  `is_required` TINYINT(1) NOT NULL DEFAULT 1,
  `placeholder` VARCHAR(150) NULL,
  `options_json` TEXT NULL,
  `help_text` VARCHAR(255) NULL,
  `sort_order` INT NOT NULL DEFAULT 0,
  INDEX `idx_field_service` (`service_id`),
  CONSTRAINT `fk_form_service` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- 11. Customer Orders Table
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `orders` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `order_number` VARCHAR(50) NOT NULL UNIQUE,
  `user_id` INT UNSIGNED NOT NULL,
  `service_id` INT UNSIGNED NOT NULL,
  `service_name` VARCHAR(150) NOT NULL,
  `service_price` DECIMAL(10, 2) NOT NULL,
  `form_values_json` LONGTEXT NOT NULL,
  `status` ENUM('pending','processing','needs_info','completed','rejected','cancelled','refunded') NOT NULL DEFAULT 'pending',
  `admin_note` TEXT NULL,
  `deliverable_file` VARCHAR(255) NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_ord_num` (`order_number`),
  INDEX `idx_ord_status` (`status`),
  INDEX `idx_ord_user` (`user_id`),
  CONSTRAINT `fk_order_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- 12. Support Tickets & Messages
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `support_tickets` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `ticket_number` VARCHAR(50) NOT NULL UNIQUE,
  `user_id` INT UNSIGNED NOT NULL,
  `subject` VARCHAR(200) NOT NULL,
  `status` ENUM('open','in_progress','closed') NOT NULL DEFAULT 'open',
  `priority` ENUM('low','normal','high') NOT NULL DEFAULT 'normal',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_ticket_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `ticket_messages` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `ticket_id` INT UNSIGNED NOT NULL,
  `sender_type` ENUM('user', 'admin') NOT NULL,
  `message` TEXT NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_msg_ticket` FOREIGN KEY (`ticket_id`) REFERENCES `support_tickets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- 13. Admin Audit Logs (Immutable Security Trail)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `admin_audit_logs` (
  `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `admin_id` INT UNSIGNED NOT NULL,
  `admin_name` VARCHAR(100) NOT NULL,
  `action` VARCHAR(100) NOT NULL,
  `target_type` VARCHAR(50) NOT NULL,
  `target_id` VARCHAR(50) NOT NULL,
  `old_value` TEXT NULL,
  `new_value` TEXT NULL,
  `ip_address` VARCHAR(45) NOT NULL,
  `user_agent` VARCHAR(255) NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_audit_action` (`action`),
  INDEX `idx_audit_admin` (`admin_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- 14. Site Settings Table
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `site_settings` (
  `setting_key` VARCHAR(100) PRIMARY KEY,
  `setting_value` LONGTEXT NULL,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- 15. SEED DATA (Roles, Permissions, Categories, Settings)
-- -----------------------------------------------------------------------------

-- Roles
INSERT INTO `roles` (`id`, `name`, `description`, `is_system`) VALUES
('role_super_admin', 'Super Admin', 'সম্পূর্ণ সিস্টেম এক্সেস ও কনফিগারেশন', 1),
('role_admin', 'Admin', 'দৈনন্দিন কার্যক্রম ও ইউজার পরিচালনা', 1),
('role_order_manager', 'Order Manager', 'অর্ডার যাচাই, ডেলিভারি ও প্রসেসিং', 1),
('role_finance_manager', 'Finance Manager', 'রিচার্জ ভেরিফিকেশন ও ট্রানজেকশন পরিচালনা', 1),
('role_support_staff', 'Support Staff', 'গ্রাহক সহায়তা ও টিকিট রিপ্লাই', 1)
ON DUPLICATE KEY UPDATE `name`=VALUES(`name`);

-- Categories
INSERT INTO `service_categories` (`id`, `name`, `bangla_name`, `icon_name`, `description`) VALUES
('cat_nid', 'NID Services', 'জাতীয় পরিচয়পত্র সেবা', 'CreditCard', 'NID সংক্রান্ত যাবতীয় সরকারি ও অনলাইন ভেরিফিকেশন সেবা'),
('cat_server_copy', 'Server Copy', 'সার্ভার কপি সেবা', 'Server', 'নির্বাচন কমিশন ও অফিসিয়াল ডেটাবেজ সার্ভার কপি উত্তোলন'),
('cat_birth', 'Birth Registration', 'জন্ম নিবন্ধন সেবা', 'FileText', 'অনলাইন জন্ম নিবন্ধন যাচাই ও নতুন আবেদন'),
('cat_tin', 'TIN Certificate', 'টিআইএন সার্টিফিকেট', 'Layers', 'ই-ট্যাক্স আইডেন্টিফিকেশন সার্টিফিকেট ও আয়কর সেবা')
ON DUPLICATE KEY UPDATE `bangla_name`=VALUES(`bangla_name`);

-- Default Site Settings
INSERT INTO `site_settings` (`setting_key`, `setting_value`) VALUES
('site_name', 'DigiSeba BD'),
('site_tagline', 'স্মার্ট ডিজিটাল সেবা ও দ্রুত সমাধান'),
('phone', '01700000000'),
('whatsapp', '01700000000'),
('email', 'support@digisebabd.com'),
('min_recharge', '110.00'),
('bkash_number', '01881234567'),
('nagad_number', '01799887766'),
('notice_title', 'গুরুত্বপূর্ণ নোটিশ'),
('notice_content', 'সু-স্বাগতম! Contact Support এ ক্লিক করে আমাদের WhatsApp Announcement গ্রুপে জয়েন থাকবেন।'),
('notice_active', '1'),
('maintenance_mode', '0');
-- -----------------------------------------------------------------------------
-- 15. Privacy-First Page Views & Visitor Analytics Table
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `page_views` (
  `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `page_url` VARCHAR(150) NOT NULL,
  `referrer` VARCHAR(150) NULL,
  `device_type` ENUM('mobile', 'desktop') NOT NULL DEFAULT 'mobile',
  `visitor_hash` VARCHAR(64) NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_pv_url` (`page_url`),
  INDEX `idx_pv_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- 16. System Error Logs Table
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `error_logs` (
  `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `category` VARCHAR(50) NOT NULL,
  `message` VARCHAR(255) NOT NULL,
  `severity` ENUM('info', 'warning', 'critical') NOT NULL DEFAULT 'info',
  `route` VARCHAR(100) NULL,
  `ip_address` VARCHAR(45) NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_err_cat` (`category`),
  INDEX `idx_err_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- 17. In-app Notifications (recharge, order & wallet alerts for customers/admins)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `notifications` (
  `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT UNSIGNED NOT NULL,
  `type` ENUM('info','success','warning','alert') NOT NULL DEFAULT 'info',
  `title` VARCHAR(150) NOT NULL,
  `message` VARCHAR(500) NOT NULL,
  `link` VARCHAR(150) NULL,
  `is_read` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_notif_user` (`user_id`, `is_read`, `id`),
  CONSTRAINT `fk_notif_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
