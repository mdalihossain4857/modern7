<?php
/**
 * DigiSeba BD - Services & Form Fields API
 * Location: htdocs/api/services.php
 */

declare(strict_types=1);
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/security.php';

$pdo = getDbConnection();
$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

if ($method === 'GET' && ($action === 'list' || empty($action))) {
    $stmt = $pdo->query("SELECT * FROM services WHERE status != 'archived' ORDER BY id ASC");
    $services = $stmt->fetchAll();

    $stmtFields = $pdo->query("SELECT * FROM service_form_fields ORDER BY sort_order ASC");
    $fields = $stmtFields->fetchAll();

    $fieldsByService = [];
    foreach ($fields as $f) {
        $fieldsByService[$f['service_id']][] = [
            'id' => $f['field_key'],
            'label' => $f['label'],
            'banglaLabel' => $f['bangla_label'],
            'type' => $f['field_type'],
            'required' => (bool)$f['is_required'],
            'placeholder' => $f['placeholder'],
            'options' => $f['options_json'] ? json_decode($f['options_json'], true) : [],
            'helpText' => $f['help_text']
        ];
    }

    $response = [];
    foreach ($services as $s) {
        $response[] = [
            'id' => (string)$s['id'],
            'serviceCode' => $s['service_code'],
            'name' => $s['name'],
            'banglaName' => $s['bangla_name'],
            'categoryId' => $s['category_id'],
            'description' => $s['description'],
            'price' => (float)$s['price'],
            'estimatedDeliveryTime' => $s['estimated_delivery_time'],
            'status' => $s['status'],
            'fields' => $fieldsByService[$s['id']] ?? []
        ];
    }

    jsonResponse(['success' => true, 'services' => $response, 'data' => ['services' => $response]]);
}
