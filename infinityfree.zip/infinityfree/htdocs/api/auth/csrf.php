<?php $_GET['route'] = 'auth/csrf'; require dirname(__DIR__) . '/index.php';
