<?php $_GET['route'] = 'auth/login'; require dirname(__DIR__) . '/index.php';
