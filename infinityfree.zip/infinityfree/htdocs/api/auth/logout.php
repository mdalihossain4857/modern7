<?php $_GET['route'] = 'auth/logout'; require dirname(__DIR__) . '/index.php';
