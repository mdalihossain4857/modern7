<?php $_GET['route'] = 'auth/change_password'; require dirname(__DIR__) . '/index.php';
