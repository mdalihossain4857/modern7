<?php $_GET['route'] = 'auth/register'; require dirname(__DIR__) . '/index.php';
