<?php $_GET['route'] = 'auth/me'; require dirname(__DIR__) . '/index.php';
