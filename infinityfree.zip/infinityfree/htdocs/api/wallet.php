<?php
/**
 * DigiSeba BD - Wallet & Recharge API (With Atomic Transactions)
 * Location: htdocs/api/wallet.php
 */

declare(strict_types=1);
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/security.php';

$pdo = getDbConnection();
$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

if ($method === 'POST' && $action === 'recharge_request') {
    $user = requireAuth();
    validateCsrf();
    $data = json_decode(file_get_contents('php://input'), true) ?: [];

    $amount = (float)($data['amount'] ?? 0);
    $payMethod = sanitize((string)($data['method'] ?? 'bKash'));
    $senderNumber = sanitize((string)($data['sender_number'] ?? $data['senderNumber'] ?? ''));
    $trxId = strtoupper(sanitize((string)($data['trx_id'] ?? $data['trxId'] ?? '')));

    if ($amount < 110.00) {
        jsonResponse(['success' => false, 'message' => 'সর্বনিম্ন রিচার্জ পরিমাণ ১১০.০০ টাকা'], 400);
    }
    if (empty($trxId) || strlen($trxId) < 6) {
        jsonResponse(['success' => false, 'message' => 'সঠিক TrxID প্রদান করুন'], 400);
    }

    try {
        $stmt = $pdo->prepare("INSERT INTO recharge_requests (user_id, method, amount, sender_number, trx_id, status) VALUES (?, ?, ?, ?, ?, 'pending')");
        $stmt->execute([$user['id'], $payMethod, $amount, $senderNumber, $trxId]);
        jsonResponse(['success' => true, 'message' => 'রিচার্জ রিকোয়েস্ট সফলভাবে জমা হয়েছে। অ্যাডমিন ভেরিফাইয়ের পর ব্যালেন্স যোগ হবে।']);
    } catch (PDOException $e) {
        if ($e->getCode() == 23000) {
            jsonResponse(['success' => false, 'message' => 'এই TrxID দিয়ে পূর্বে রিকোয়েস্ট করা হয়েছে। ডুপ্লিকেট পেমেন্ট গ্রহণযোগ্য নয়।'], 400);
        }
        error_log("Recharge request error: " . $e->getMessage());
        jsonResponse(['success' => false, 'message' => 'ডাটাবেজ ত্রুটি ঘটেছে।'], 500);
    }
}

if ($method === 'POST' && $action === 'approve_recharge') {
    $admin = requireAdmin();
    validateCsrf();
    $data = json_decode(file_get_contents('php://input'), true) ?: [];
    $requestId = (int)($data['request_id'] ?? $data['rechargeId'] ?? 0);

    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare("SELECT * FROM recharge_requests WHERE id = ? FOR UPDATE");
        $stmt->execute([$requestId]);
        $req = $stmt->fetch();

        if (!$req) {
            $pdo->rollBack();
            jsonResponse(['success' => false, 'message' => 'রিকোয়েস্ট পাওয়া যায়নি'], 404);
        }

        if ($req['status'] === 'approved') {
            $pdo->rollBack();
            jsonResponse(['success' => false, 'message' => 'ইতিমধ্যেই অনুমোদিত হয়েছে'], 400);
        }

        $stmtUpdate = $pdo->prepare("UPDATE recharge_requests SET status = 'approved', approved_at = NOW(), verified_by_admin_id = ? WHERE id = ?");
        $stmtUpdate->execute([$admin['id'], $requestId]);

        $stmtWallet = $pdo->prepare("INSERT INTO wallets (user_id, balance) VALUES (?, ?) ON DUPLICATE KEY UPDATE balance = balance + ?");
        $stmtWallet->execute([$req['user_id'], $req['amount'], $req['amount']]);

        $stmtBal = $pdo->prepare("SELECT balance FROM wallets WHERE user_id = ?");
        $stmtBal->execute([$req['user_id']]);
        $newBalance = (float)$stmtBal->fetchColumn();

        $stmtLedger = $pdo->prepare("INSERT INTO wallet_ledger (user_id, amount, type, category, reference_id, description, balance_after) VALUES (?, ?, 'credit', 'recharge', ?, ?, ?)");
        $desc = "{$req['method']} Manual Recharge Approved (Trx: {$req['trx_id']})";
        $stmtLedger->execute([$req['user_id'], $req['amount'], $req['trx_id'], $desc, $newBalance]);

        $pdo->commit();
        jsonResponse(['success' => true, 'message' => 'রিচার্জ সফলভাবে অনুমোদিত হয়েছে এবং গ্রাহকের ওয়ালেটে টাকা যুক্ত হয়েছে।', 'new_balance' => $newBalance]);
    } catch (Exception $e) {
        $pdo->rollBack();
        error_log("Approve recharge error: " . $e->getMessage());
        jsonResponse(['success' => false, 'message' => 'ব্যালেন্স যুক্ত করতে ব্যর্থ হয়েছে।'], 500);
    }
}

if ($method === 'GET' && $action === 'my_wallet') {
    $user = requireAuth();

    $stmtBal = $pdo->prepare("SELECT balance FROM wallets WHERE user_id = ?");
    $stmtBal->execute([$user['id']]);
    $balance = (float)($stmtBal->fetchColumn() ?: 0.0);

    $stmtLed = $pdo->prepare("SELECT * FROM wallet_ledger WHERE user_id = ? ORDER BY id DESC LIMIT 50");
    $stmtLed->execute([$user['id']]);
    $ledger = $stmtLed->fetchAll();

    jsonResponse([
        'success' => true,
        'balance' => $balance,
        'ledger' => $ledger
    ]);
}
