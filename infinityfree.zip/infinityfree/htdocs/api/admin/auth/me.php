<?php $_GET['route'] = 'admin/auth/me'; require dirname(__DIR__, 2) . '/index.php';
