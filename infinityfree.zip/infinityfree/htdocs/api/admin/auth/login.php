<?php $_GET['route'] = 'admin/auth/login'; require dirname(__DIR__, 2) . '/index.php';
