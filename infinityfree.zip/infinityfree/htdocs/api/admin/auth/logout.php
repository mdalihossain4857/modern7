<?php $_GET['route'] = 'admin/auth/logout'; require dirname(__DIR__, 2) . '/index.php';
