<?php
/**
 * DigiSeba BD - Authenticated Secure Document Download Endpoint
 * Location: htdocs/api/files.php
 * 
 * Verifies that only the file owner or an authenticated admin can access private files.
 * Prevents direct directory traversal, IDOR, and public exposure.
 */

declare(strict_types=1);

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/security.php';

$user = requireAuth();
$pdo = getDbConnection();

$filename = basename(trim((string)($_GET['file'] ?? '')));

if (empty($filename)) {
    jsonResponse(['success' => false, 'message' => 'ফাইলের নাম উল্লেখ করা হয়নি।'], 400);
}

// Prevent path traversal
if (strpos($filename, '..') !== false || strpos($filename, '/') !== false || strpos($filename, '\\') !== false) {
    jsonResponse(['success' => false, 'message' => 'অবৈধ পাথ সনাক্ত হয়েছে।'], 403);
}

// Determine storage path inside /api/storage/uploads
$storageBase = realpath(__DIR__ . '/storage/uploads');
if (!$storageBase) {
    $storageBase = __DIR__ . '/storage/uploads';
}
$filePath = $storageBase . DIRECTORY_SEPARATOR . $filename;

if (!file_exists($filePath)) {
    jsonResponse(['success' => false, 'message' => 'ফাইলটি খুঁজে পাওয়া যায়নি।'], 404);
}

// IDOR & Authorization check: verify file belongs to current user unless user is admin
$isAdmin = in_array($user['role'], ['admin', 'super_admin'], true);

if (!$isAdmin) {
    $stmtCheck = $pdo->prepare("
        SELECT 1 FROM orders WHERE user_id = ? AND (deliverable_file = ? OR form_values_json LIKE ?)
        UNION
        SELECT 1 FROM recharge_requests WHERE user_id = ? AND proof_screenshot = ?
    ");
    $likeStr = '%' . $filename . '%';
    $stmtCheck->execute([$user['id'], $filename, $likeStr, $user['id'], $filename]);
    $isOwner = (bool)$stmtCheck->fetchColumn();

    if (!$isOwner) {
        jsonResponse(['success' => false, 'message' => 'এই ফাইলে প্রবেশের অনুমতি আপনার নেই।'], 403);
    }
}

$mimeType = mime_content_type($filePath) ?: 'application/octet-stream';
header('Content-Type: ' . $mimeType);
header('Content-Length: ' . filesize($filePath));
header('Content-Disposition: inline; filename="' . $filename . '"');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, max-age=3600');

readfile($filePath);
exit;
