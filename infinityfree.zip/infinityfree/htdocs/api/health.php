<?php
/**
 * DigiSeba BD - System Health Check Endpoint
 * Location: htdocs/api/health.php
 */

declare(strict_types=1);

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/security.php';

$pdo = getDbConnection();
$dbConnected = false;

try {
    $stmt = $pdo->query("SELECT 1");
    if ($stmt && $stmt->fetchColumn() == 1) {
        $dbConnected = true;
    }
} catch (Exception $e) {
    error_log("Health check database error: " . $e->getMessage());
    $dbConnected = false;
}

jsonResponse([
    'success'     => $dbConnected,
    'status'      => $dbConnected ? 'healthy' : 'degraded',
    'timestamp'   => date('Y-m-d H:i:s'),
    'php_version' => PHP_MAJOR_VERSION . '.' . PHP_MINOR_VERSION,
    'database'    => $dbConnected ? 'connected' : 'disconnected'
], $dbConnected ? 200 : 503);
