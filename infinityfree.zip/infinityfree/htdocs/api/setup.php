<?php
/**
 * DigiSeba BD - Production Initial Super Admin Setup Wizard
 * Location: /php/setup.php
 * 
 * Secure one-time initialization script.
 * Self-locks immediately upon successful Super Admin creation.
 */

declare(strict_types=1);

ini_set('display_errors', '0');
ini_set('log_errors', '1');

require_once __DIR__ . '/config/database.php';

$lockFile = __DIR__ . '/setup.lock';
if (file_exists($lockFile)) {
    http_response_code(403);
    die("<!DOCTYPE html><html lang='bn'><head><meta charset='UTF-8'><title>লক করা হয়েছে</title><style>body{font-family:sans-serif;background:#0f172a;color:#f8fafc;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;}.c{background:#1e293b;padding:2rem;border-radius:1rem;max-width:440px;border:1px solid #ef4444;text-align:center;}</style></head><body><div class='c'><h2 style='color:#ef4444;'>সেটআপ ইতিমধ্যে লক করা হয়েছে</h2><p style='color:#94a3b8;'>নিরাপত্তার স্বার্থে সুপার অ্যাডমিন কনফিগারেশনের পর setup.php লক করে রাখা হয়েছে।</p><p><a href='/admin' style='color:#17B978;'>অ্যাডমিন প্যানেলে যান</a></p></div></body></html>");
}

$pdo = getDbConnection();
$message = '';
$isSuccess = false;

// Check if any Super Admin already exists in the database
try {
    $stmtCheck = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'admin'");
    $existingAdminCount = (int)$stmtCheck->fetchColumn();
    if ($existingAdminCount > 0) {
        file_put_contents($lockFile, date('Y-m-d H:i:s') . " - Auto-locked (admin already exists)");
        http_response_code(403);
        die("<!DOCTYPE html><html lang='bn'><head><meta charset='UTF-8'><title>লক করা হয়েছে</title><style>body{font-family:sans-serif;background:#0f172a;color:#f8fafc;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;}.c{background:#1e293b;padding:2rem;border-radius:1rem;max-width:440px;border:1px solid #334155;text-align:center;}</style></head><body><div class='c'><h2 style='color:#17B978;'>অ্যাডমিন ইতিমধ্যে বিদ্যমান</h2><p style='color:#94a3b8;'>ডাটাবেজে ইতিমধ্যেই অ্যাডমিন অ্যাকাউন্ট রয়েছে। setup.php লক করা হয়েছে।</p><p><a href='/admin' style='color:#17B978;'>লগইন পাতায় যান</a></p></div></body></html>");
    }
} catch (PDOException $e) {
    $message = "ডাটাবেজ টেবিল অনুপস্থিত! অনুগ্রহ করে প্রথমে phpMyAdmin এ schema.sql ইমপোর্ট করুন।";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && empty($message)) {
    $name = trim($_POST['name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';

    if (empty($name) || empty($phone) || empty($email) || empty($password)) {
        $message = "সকল ঘর পূরণ করা আবশ্যক।";
    } elseif ($password !== $confirmPassword) {
        $message = "পাসওয়ার্ড দুটি মিলছে না।";
    } elseif (strlen($password) < 8) {
        $message = "পাসওয়ার্ড কমপক্ষে ৮ অক্ষরের হতে হবে।";
    } else {
        $passwordHash = password_hash($password, PASSWORD_BCRYPT);
        try {
            $pdo->beginTransaction();

            $stmt = $pdo->prepare("INSERT INTO users (name, phone, email, password_hash, role, status) VALUES (?, ?, ?, ?, 'admin', 'active')");
            $stmt->execute([$name, $phone, $email, $passwordHash]);
            $adminId = (int)$pdo->lastInsertId();

            // Create admin wallet record
            $stmtWal = $pdo->prepare("INSERT INTO wallets (user_id, balance) VALUES (?, 0.00)");
            $stmtWal->execute([$adminId]);

            $pdo->commit();

            // Create irreversible setup lock file
            file_put_contents($lockFile, date('Y-m-d H:i:s') . " - Configured for Super Admin: " . $email);
            $isSuccess = true;
            $message = "প্রথম সুপার অ্যাডমিন অ্যাকাউন্ট সফলভাবে তৈরি হয়েছে! সেটআপ ফাইল লক করা হলো।";
        } catch (PDOException $e) {
            $pdo->rollBack();
            $message = "অ্যাকাউন্ট তৈরিতে ত্রুটি: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="bn">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>DigiSeba BD — প্রথম সুপার অ্যাডমিন সেটআপ</title>
  <link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;600;700&display=swap" rel="stylesheet">
  <style>
    body { font-family: 'Hind Siliguri', -apple-system, sans-serif; background: #0f172a; color: #f8fafc; display: flex; align-items: center; justify-content: center; min-height: 100vh; margin: 0; padding: 1.5rem; box-sizing: border-box; }
    .card { background: #1e293b; border: 1px solid #334155; padding: 2.25rem 2rem; border-radius: 1.25rem; width: 100%; max-width: 460px; box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.5); }
    h2 { color: #17B978; margin-top: 0; font-size: 1.5rem; }
    p { font-size: 0.85rem; color: #94a3b8; line-height: 1.5; margin-bottom: 1.5rem; }
    label { display: block; font-size: 0.8rem; font-weight: 600; color: #cbd5e1; margin-bottom: 0.35rem; }
    input { width: 100%; padding: 0.75rem; margin-bottom: 1rem; border-radius: 0.6rem; border: 1px solid #475569; background: #0f172a; color: #fff; box-sizing: border-box; font-size: 0.9rem; }
    input:focus { outline: none; border-color: #17B978; }
    button { width: 100%; padding: 0.85rem; background: #17B978; color: #fff; font-weight: bold; border: none; border-radius: 0.6rem; cursor: pointer; font-size: 0.95rem; margin-top: 0.5rem; }
    button:hover { background: #0F9D69; }
    .msg { padding: 0.75rem 1rem; border-radius: 0.5rem; margin-bottom: 1.25rem; font-size: 0.85rem; }
    .error { background: #7f1d1d; color: #fecaca; border: 1px solid #991b1b; }
    .success { background: #064e3b; color: #a7f3d0; border: 1px solid #065f46; }
    .link-btn { display: inline-block; background: #17B978; color: #fff; padding: 0.75rem 1.5rem; border-radius: 0.5rem; text-decoration: none; font-weight: bold; }
  </style>
</head>
<body>
  <div class="card">
    <h2>DigiSeba BD — প্রথম সুপার অ্যাডমিন সেটআপ</h2>
    <p>নিরাপত্তার স্বার্থে কোনো ডিফল্ট বা হার্ডকোড করা পাসওয়ার্ড নেই। আপনার আসল ও শক্তিশালী অ্যাডমিন পাসওয়ার্ড দিয়ে অ্যাকাউন্ট কনফিগার করুন।</p>

    <?php if (!empty($message)): ?>
      <div class="msg <?= $isSuccess ? 'success' : 'error' ?>"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <?php if (!$isSuccess): ?>
    <form method="POST">
      <label>সুপার অ্যাডমিনের নাম</label>
      <input type="text" name="name" placeholder="যেমন: Chief Administrator" required>

      <label>মোবাইল নম্বর (লগইনে ব্যবহার করা যাবে)</label>
      <input type="text" name="phone" placeholder="017XXXXXXXX" required>

      <label>অ্যাডমিন ইমেইল</label>
      <input type="email" name="email" placeholder="admin@yourdomain.com" required>

      <label>শক্তিশালী পাসওয়ার্ড (কমপক্ষে ৮ অক্ষর)</label>
      <input type="password" name="password" minlength="8" required>

      <label>পাসওয়ার্ড নিশ্চিত করুন</label>
      <input type="password" name="confirm_password" minlength="8" required>

      <button type="submit">সুপার অ্যাডমিন অ্যাকাউন্ট তৈরি করুন</button>
    </form>
    <?php else: ?>
      <div style="text-align: center; margin-top: 1.5rem;">
        <a href="/admin/login" class="link-btn">অ্যাডমিন প্যানেলে লগইন করুন</a>
      </div>
    <?php endif; ?>
  </div>
</body>
</html>
