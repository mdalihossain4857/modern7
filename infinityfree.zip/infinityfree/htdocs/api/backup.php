<?php
/**
 * DigiSeba BD - Production Backup & Restore Engine
 * Location: htdocs/api/backup.php
 * 
 * Generates clean MySQL SQL dumps using PDO for InfinityFree shared hosting.
 * Excludes passwords, hashes, and internal secret keys.
 */

declare(strict_types=1);

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/security.php';

$admin = requireAdmin();
$pdo = getDbConnection();
$action = trim((string)($_GET['action'] ?? 'list'));

// 1. Download Backup File
if ($action === 'download') {
    $id = preg_replace('/[^a-zA-Z0-9_-]/', '', (string)($_GET['id'] ?? ''));
    if (empty($id)) {
        jsonResponse(['success' => false, 'message' => 'অবৈধ ব্যাকআপ আইডি'], 400);
    }

    $backupDir = __DIR__ . '/storage/backups';
    $files = glob($backupDir . '/*' . $id . '*');

    if (empty($files) || !file_exists($files[0])) {
        header('Content-Type: application/sql');
        header('Content-Disposition: attachment; filename="digiseba_backup_' . $id . '.sql"');
        echo "-- ========================================================\n";
        echo "-- DigiSeba BD - SQL Database Dump\n";
        echo "-- Generated on: " . date('Y-m-d H:i:s') . "\n";
        echo "-- ========================================================\n\n";
        echo "SET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS = 0;\n\n";

        $tables = ['service_categories', 'services', 'service_form_fields', 'roles', 'permissions', 'site_settings'];
        foreach ($tables as $t) {
            echo "-- Table structure for `{$t}`\n";
            $createStmt = $pdo->query("SHOW CREATE TABLE `{$t}`")->fetch();
            if ($createStmt && isset($createStmt['Create Table'])) {
                echo $createStmt['Create Table'] . ";\n\n";
            }
        }
        echo "SET FOREIGN_KEY_CHECKS = 1;\n";
        exit;
    }

    $file = $files[0];
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . basename($file) . '"');
    header('Content-Length: ' . filesize($file));
    readfile($file);
    exit;
}

// 2. Generate New SQL Backup
if ($action === 'create' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    validateCsrf();
    $type = trim((string)($_POST['type'] ?? 'database'));

    $backupDir = __DIR__ . '/storage/backups';
    if (!is_dir($backupDir)) {
        mkdir($backupDir, 0755, true);
    }

    $timestamp = date('Ymd_His');
    $filename = "digiseba_{$type}_{$timestamp}.sql";
    $targetPath = $backupDir . '/' . $filename;

    try {
        $tables = [
            'roles', 'permissions', 'role_permissions', 'users', 'wallets', 
            'wallet_ledger', 'recharge_requests', 'service_categories', 'services', 
            'service_form_fields', 'orders', 'support_tickets', 'ticket_messages', 
            'site_settings', 'admin_audit_logs'
        ];

        $sqlDump = "-- DigiSeba BD Automated SQL Backup\n";
        $sqlDump .= "-- Export Time: " . date('Y-m-d H:i:s') . "\n";
        $sqlDump .= "SET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS = 0;\n\n";

        foreach ($tables as $table) {
            $stmt = $pdo->query("SHOW CREATE TABLE `{$table}`");
            $row = $stmt->fetch();
            if ($row && isset($row['Create Table'])) {
                $sqlDump .= "DROP TABLE IF EXISTS `{$table}`;\n";
                $sqlDump .= $row['Create Table'] . ";\n\n";
            }

            $query = "SELECT * FROM `{$table}`";
            if ($table === 'users') {
                $query = "SELECT id, name, phone, email, 'PROTECTED_HASH' as password_hash, role, role_id, status, avatar, created_at, updated_at FROM `users`";
            }

            $stmtData = $pdo->query($query);
            $rows = $stmtData->fetchAll(PDO::FETCH_ASSOC);

            if (!empty($rows)) {
                $sqlDump .= "INSERT INTO `{$table}` VALUES \n";
                $inserts = [];
                foreach ($rows as $r) {
                    $escaped = array_map(function($v) use ($pdo) {
                        return $v === null ? 'NULL' : $pdo->quote((string)$v);
                    }, $r);
                    $inserts[] = "(" . implode(', ', $escaped) . ")";
                }
                $sqlDump .= implode(",\n", $inserts) . ";\n\n";
            }
        }

        $sqlDump .= "SET FOREIGN_KEY_CHECKS = 1;\n";
        file_put_contents($targetPath, $sqlDump);

        jsonResponse([
            'success' => true,
            'message' => 'ডাটাবেস ব্যাকআপ সফলভাবে প্রস্তুত হয়েছে',
            'filename' => $filename,
            'size' => filesize($targetPath)
        ]);
    } catch (Exception $e) {
        error_log("Backup generation error: " . $e->getMessage());
        jsonResponse(['success' => false, 'message' => 'ব্যাকআপ তৈরিতে ত্রুটি ঘটেছে।'], 500);
    }
}
