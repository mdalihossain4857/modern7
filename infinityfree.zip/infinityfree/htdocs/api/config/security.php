<?php
/**
 * DigiSeba BD - Production Security, Session & RBAC Hardening
 * Location: htdocs/api/config/security.php
 * Compatible with: InfinityFree PHP 8.x + MySQL & Cloudflare SSL
 */

declare(strict_types=1);

// 0. Global Exception & Fatal Error Handler (Prevents blank/HTML HTTP 500 crashes)
set_exception_handler(function (Throwable $e): void {
    error_log('[DigiSeba Uncaught Exception] ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());
    if (!headers_sent()) {
        http_response_code(500);
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    }
    echo json_encode([
        'success' => false,
        'message' => 'সার্ভার প্রক্রিয়াকরণে সাময়িক ত্রুটি ঘটেছে। অনুগ্রহ করে ডাটাবেজ কনফিগারেশন ও টেবিল যাচাই করুন।'
    ], JSON_UNESCAPED_UNICODE);
    exit;
});

// 1. Production Session & Cookie Hardening (InfinityFree + Cloudflare SSL Ready)
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', '1');
    ini_set('session.use_only_cookies', '1');
    ini_set('session.use_strict_mode', '1');
    ini_set('session.cookie_samesite', 'Lax');

    $cfVisitorHttps = false;
    if (!empty($_SERVER['HTTP_CF_VISITOR'])) {
        $cfData = json_decode((string)$_SERVER['HTTP_CF_VISITOR'], true);
        $cfVisitorHttps = is_array($cfData) && (($cfData['scheme'] ?? '') === 'https');
    }

    $isHttps = (
        (!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off') ||
        (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower((string)$_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https') ||
        $cfVisitorHttps ||
        (!empty($_SERVER['SERVER_PORT']) && (int)$_SERVER['SERVER_PORT'] === 443)
    );

    if ($isHttps) {
        ini_set('session.cookie_secure', '1');
    }

    // Ensure session save path is writable on shared hosting
    $currentSavePath = session_save_path();
    if (!empty($currentSavePath) && !@is_writable($currentSavePath)) {
        $fallbackSessionDir = __DIR__ . '/../storage/sessions';
        if (!is_dir($fallbackSessionDir)) {
            @mkdir($fallbackSessionDir, 0700, true);
        }
        if (@is_writable($fallbackSessionDir)) {
            session_save_path($fallbackSessionDir);
        } elseif (@is_writable(sys_get_temp_dir())) {
            session_save_path(sys_get_temp_dir());
        }
    }

    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'domain'   => '',
        'secure'   => $isHttps,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);

    @session_start();
}

// 2. JSON API Response Helper (With anti-caching headers for auth safety)
function jsonResponse(array $data, int $statusCode = 200): void {
    if (!headers_sent()) {
        http_response_code($statusCode);
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Pragma: no-cache');
        header('Expires: 0');
    }
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

// 3. String Sanitizer
function sanitize(string $input): string {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

// 4. Safe Request Headers Helper (Compatible with Apache, LiteSpeed, and PHP-FPM)
function getRequestHeaders(): array {
    $headers = [];
    if (function_exists('getallheaders')) {
        $raw = getallheaders();
        if (is_array($raw)) {
            foreach ($raw as $k => $v) {
                $headers[strtolower((string)$k)] = (string)$v;
            }
        }
    }
    foreach ($_SERVER as $key => $value) {
        if (str_starts_with($key, 'HTTP_')) {
            $headerName = strtolower(str_replace('_', '-', substr($key, 5)));
            if (!isset($headers[$headerName])) {
                $headers[$headerName] = (string)$value;
            }
        }
    }
    return $headers;
}

// 5. CSRF Protection
function generateCsrfToken(): string {
    if (empty($_SESSION['csrf_token']) || !is_string($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function validateCsrf(?array $jsonBody = null): void {
    $method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
    if (in_array($method, ['POST', 'PUT', 'DELETE', 'PATCH'], true)) {
        $headers = getRequestHeaders();
        $token = $headers['x-csrf-token']
            ?? ($_POST['csrf_token'] ?? ($jsonBody['csrf_token'] ?? ''));

        if (empty($_SESSION['csrf_token']) || empty($token) || !hash_equals((string)$_SESSION['csrf_token'], (string)$token)) {
            jsonResponse([
                'success' => false,
                'message' => 'নিরাপত্তা ত্রুটি: অবৈধ বা মেয়াদোত্তীর্ণ CSRF টোকেন। অনুগ্রহ করে পৃষ্ঠাটি রিফ্রেশ করে আবার চেষ্টা করুন।'
            ], 403);
        }
    }
}

// 6. Complete Server-Side Session Destruction Helper
function destroyAuthSession(): void {
    $_SESSION = [];

    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', [
            'expires'  => time() - 42000,
            'path'     => $params['path'] ?: '/',
            'domain'   => $params['domain'] ?: '',
            'secure'   => (bool)$params['secure'],
            'httponly' => (bool)$params['httponly'],
            'samesite' => $params['samesite'] ?: 'Lax',
        ]);
    }

    if (session_status() === PHP_SESSION_ACTIVE) {
        @session_destroy();
    }
}

// 7. Authentication Guards (Never trusts client localStorage or demo IDs)
function requireAuth(): array {
    $rawUserId = $_SESSION['user_id'] ?? null;
    $userId = is_numeric($rawUserId) ? (int)$rawUserId : 0;

    if ($userId <= 0) {
        jsonResponse([
            'success'       => false,
            'authenticated' => false,
            'message'       => 'অননুমোদিত অ্যাক্সেস! অনুগ্রহ করে আপনার অ্যাকাউন্টে লগইন করুন।'
        ], 401);
    }

    return [
        'id'   => $userId,
        'role' => (string)($_SESSION['user_role'] ?? 'customer'),
        'name' => (string)($_SESSION['user_name'] ?? 'User')
    ];
}

function requireAdmin(): array {
    $user = requireAuth();
    if (!in_array($user['role'], ['admin', 'super_admin', 'staff'], true)) {
        jsonResponse([
            'success' => false,
            'message' => 'অ্যাডমিন অধিকার প্রয়োজন। গ্রাহক অ্যাকাউন্ট থেকে এই রিসোর্সে প্রবেশ নিষিদ্ধ (HTTP 403)।'
        ], 403);
    }
    return $user;
}

// 8. Role-Based Access Control (RBAC) Permission Guard
function requirePermission(PDO $pdo, string $permissionSlug): array {
    $admin = requireAdmin();
    $userId = $admin['id'];

    // Admin and Super Admin roles have full system access
    if (in_array($admin['role'], ['admin', 'super_admin'], true)) {
        return $admin;
    }

    // Check if staff member is assigned to role_super_admin or role_admin
    $stmtRole = $pdo->prepare("SELECT role, role_id FROM users WHERE id = ? LIMIT 1");
    $stmtRole->execute([$userId]);
    $userRow = $stmtRole->fetch();

    if ($userRow && (in_array($userRow['role'], ['admin', 'super_admin'], true) || in_array($userRow['role_id'], ['role_super_admin', 'role_admin'], true))) {
        return $admin;
    }

    // Check granular permission via role_permissions
    $stmtPerm = $pdo->prepare("
        SELECT COUNT(*) FROM role_permissions rp
        JOIN permissions p ON rp.permission_id = p.id
        JOIN users u ON u.role_id = rp.role_id
        WHERE u.id = ? AND p.slug = ?
    ");
    $stmtPerm->execute([$userId, $permissionSlug]);
    $hasPermission = (int)$stmtPerm->fetchColumn() > 0;

    if (!$hasPermission) {
        jsonResponse([
            'success' => false,
            'message' => 'আপনার এই কাজের জন্য প্রয়োজনীয় পারমিশন নেই (' . $permissionSlug . ')'
        ], 403);
    }

    return $admin;
}

// 9. Rate Limiter (Brute Force Protection)
function checkRateLimit(string $key, int $maxAttempts = 10, int $decaySeconds = 900): bool {
    $sessionKey = 'ratelimit_' . md5($key);
    $now = time();

    if (!isset($_SESSION[$sessionKey]) || !is_array($_SESSION[$sessionKey])) {
        $_SESSION[$sessionKey] = ['attempts' => 1, 'reset_at' => $now + $decaySeconds];
        return true;
    }

    if ($now > (int)($_SESSION[$sessionKey]['reset_at'] ?? 0)) {
        $_SESSION[$sessionKey] = ['attempts' => 1, 'reset_at' => $now + $decaySeconds];
        return true;
    }

    $_SESSION[$sessionKey]['attempts'] = (int)$_SESSION[$sessionKey]['attempts'] + 1;
    if ($_SESSION[$sessionKey]['attempts'] > $maxAttempts) {
        return false;
    }

    return true;
}

function resetRateLimit(string $key): void {
    $sessionKey = 'ratelimit_' . md5($key);
    unset($_SESSION[$sessionKey]);
}

// 10. File Upload Hardening
function validateFileUpload(array $file, int $maxSizeBytes = 5242880): array {
    if (!isset($file['error']) || is_array($file['error'])) {
        return ['valid' => false, 'error' => 'অবৈধ ফাইল প্যারামিটার।'];
    }

    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['valid' => false, 'error' => 'ফাইল আপলোডে ত্রুটি ঘটেছে (কোড: ' . $file['error'] . ')'];
    }

    if ($file['size'] > $maxSizeBytes) {
        return ['valid' => false, 'error' => 'ফাইলের আকার সর্বোচ্চ ৫ মেগাবাইট হতে পারবে।'];
    }

    $originalName = (string)$file['name'];
    $ext = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));

    $allowed = ['jpg', 'jpeg', 'png', 'webp', 'pdf'];
    if (!in_array($ext, $allowed, true)) {
        return ['valid' => false, 'error' => 'শুধুমাত্র JPG, PNG, WEBP এবং PDF ফাইল গ্রহণযোগ্য।'];
    }

    if (preg_match('/\.(php|phtml|phar|exe|pl|py|cgi|sh|bash|js|html|htm)\./i', $originalName)) {
        return ['valid' => false, 'error' => 'বিপজ্জনক এক্সটেনশন ফাইল সনাক্ত হয়েছে। আপলোড বাতিল।'];
    }

    if (function_exists('finfo_open')) {
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);

        $allowedMimes = [
            'image/jpeg',
            'image/png',
            'image/webp',
            'application/pdf'
        ];

        if (!in_array($mime, $allowedMimes, true)) {
            return ['valid' => false, 'error' => 'ফাইলের ধরন অগ্রহণযোগ্য (' . htmlspecialchars((string)$mime) . ')'];
        }
    }

    $safeFilename = bin2hex(random_bytes(16)) . '.' . $ext;

    return [
        'valid'     => true,
        'safe_name' => $safeFilename,
        'tmp_path'  => $file['tmp_name'],
        'extension' => $ext,
        'size'      => $file['size']
    ];
}
