<?php
/**
 * DigiSeba BD - Production Database Connection (PDO)
 * Target Hosting: InfinityFree PHP 8.x + MySQL
 * Location: htdocs/api/config/database.php
 *
 * Open_basedir-safe credential resolution order:
 *   1. Protected config dir: htdocs/api/config/database.config.php
 *   2. Web root fallback:    htdocs/database.config.php (blocked from HTTP via .htaccess)
 *   3. Account root (only when open_basedir is unrestricted)
 */

declare(strict_types=1);

ini_set('display_errors', '0');
ini_set('log_errors', '1');

$internalConfigPath = __DIR__ . '/database.config.php';
$htdocsConfigPath   = dirname(__DIR__, 2) . '/database.config.php';

$candidateConfigs = [$internalConfigPath, $htdocsConfigPath];
if (empty(ini_get('open_basedir'))) {
    $candidateConfigs[] = dirname(__DIR__, 3) . '/database.config.php';
}

$dbConfig = [];
foreach ($candidateConfigs as $cfgPath) {
    if (@is_file($cfgPath) && @is_readable($cfgPath)) {
        $loaded = require $cfgPath;
        if (is_array($loaded)) {
            // Prefer a config file that has been populated with real credentials
            $dbConfig = $loaded;
            if (($loaded['host'] ?? 'YOUR_INFINITYFREE_MYSQL_HOST') !== 'YOUR_INFINITYFREE_MYSQL_HOST') {
                break;
            }
        }
    }
}

define('DB_HOST', (string)($dbConfig['host'] ?? (getenv('DB_HOST') ?: 'YOUR_INFINITYFREE_MYSQL_HOST')));
define('DB_PORT', (int)($dbConfig['port'] ?? (getenv('DB_PORT') ?: 3306)));
define('DB_NAME', (string)($dbConfig['database'] ?? (getenv('DB_NAME') ?: 'YOUR_DATABASE_NAME')));
define('DB_USER', (string)($dbConfig['username'] ?? (getenv('DB_USER') ?: 'YOUR_DATABASE_USER')));
define('DB_PASS', (string)($dbConfig['password'] ?? (getenv('DB_PASS') ?: 'YOUR_DATABASE_PASSWORD')));
define('DB_CHARSET', (string)($dbConfig['charset'] ?? 'utf8mb4'));

/**
 * Returns a singleton PDO connection with UTF8mb4 and transaction support.
 */
function getDbConnection(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        if (
            DB_HOST === '' ||
            DB_HOST === 'YOUR_INFINITYFREE_MYSQL_HOST' ||
            DB_NAME === 'YOUR_DATABASE_NAME' ||
            DB_USER === 'YOUR_DATABASE_USER' ||
            DB_PASS === 'YOUR_DATABASE_PASSWORD'
        ) {
            http_response_code(503);
            header('Content-Type: application/json; charset=utf-8');
            header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
            echo json_encode([
                'success' => false,
                'message' => 'ডাটাবেজ কনফিগার করা হয়নি। অনুগ্রহ করে htdocs/api/config/database.config.php ফাইলে আপনার InfinityFree MySQL তথ্য সেট করুন।'
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }

        $dsn = sprintf('mysql:host=%s;port=%d;dbname=%s;charset=%s', DB_HOST, DB_PORT, DB_NAME, DB_CHARSET);
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci"
        ];
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            error_log("Database connection failed: " . $e->getMessage());
            http_response_code(503);
            header('Content-Type: application/json; charset=utf-8');
            header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
            echo json_encode([
                'success' => false,
                'message' => 'ডাটাবেজ সংযোগে সমস্যা হয়েছে। অনুগ্রহ করে MySQL Host, Database Name, Username ও Password যাচাই করুন।'
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }
    }
    return $pdo;
}
