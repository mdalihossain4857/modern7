<?php
/**
 * DigiSeba BD - Notification helpers
 * Location: htdocs/api/config/notifications.php
 *
 * - Table is auto-created on first use (no need to re-import schema.sql).
 * - Notification failures NEVER break the main request (all errors are logged only).
 * - Always call these AFTER $pdo->commit() (CREATE TABLE causes an implicit commit in MySQL).
 */

declare(strict_types=1);

function ensureNotificationsTable(PDO $pdo): void {
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `notifications` (
          `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
          `user_id` INT UNSIGNED NOT NULL,
          `type` ENUM('info','success','warning','alert') NOT NULL DEFAULT 'info',
          `title` VARCHAR(150) NOT NULL,
          `message` VARCHAR(500) NOT NULL,
          `link` VARCHAR(150) NULL,
          `is_read` TINYINT(1) NOT NULL DEFAULT 0,
          `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
          INDEX `idx_notif_user` (`user_id`, `is_read`, `id`),
          CONSTRAINT `fk_notif_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
}

function notifText(string $s, int $max): string {
    $s = htmlspecialchars_decode(trim($s), ENT_QUOTES);
    return function_exists('mb_substr') ? mb_substr($s, 0, $max, 'UTF-8') : substr($s, 0, $max);
}

function createNotification(PDO $pdo, int $userId, string $type, string $title, string $message, ?string $link = null): void {
    if ($userId <= 0) {
        return;
    }
    if (!in_array($type, ['info', 'success', 'warning', 'alert'], true)) {
        $type = 'info';
    }
    $params = [$userId, $type, notifText($title, 150), notifText($message, 500), $link];
    $sql = "INSERT INTO notifications (user_id, type, title, message, link) VALUES (?, ?, ?, ?, ?)";

    try {
        $pdo->prepare($sql)->execute($params);
    } catch (Throwable $e) {
        // Table missing (SQLSTATE 42S02) -> create it and retry once
        try {
            ensureNotificationsTable($pdo);
            $pdo->prepare($sql)->execute($params);
        } catch (Throwable $e2) {
            error_log('[DigiSeba notifications] create failed: ' . $e2->getMessage());
        }
    }
}

/** Notify every active admin / staff account. */
function notifyAdmins(PDO $pdo, string $type, string $title, string $message, ?string $link = null): void {
    try {
        $ids = $pdo->query("SELECT id FROM users WHERE role IN ('admin','staff') AND status = 'active'")->fetchAll(PDO::FETCH_COLUMN);
    } catch (Throwable $e) {
        error_log('[DigiSeba notifications] admin lookup failed: ' . $e->getMessage());
        return;
    }
    foreach ($ids as $adminId) {
        createNotification($pdo, (int)$adminId, $type, $title, $message, $link);
    }
}

function formatTaka(float $amount): string {
    return '৳' . number_format($amount, 2);
}

/**
 * Seeds the default service catalog (same services the website shows) into MySQL.
 * The website's service catalog uses codes like "NID-GUIDE"; orders are resolved by service_code,
 * so these rows must exist in the `services` table. Idempotent: existing rows are never changed.
 */
function ensureDefaultServices(PDO $pdo): void {
    $file = __DIR__ . '/default_services.json';
    if (!is_file($file)) {
        return;
    }
    $data = json_decode((string)file_get_contents($file), true);
    if (!is_array($data)) {
        return;
    }
    try {
        $insCat = $pdo->prepare("INSERT IGNORE INTO service_categories (id, name, bangla_name, icon_name, description) VALUES (?, ?, ?, ?, ?)");
        foreach (($data['categories'] ?? []) as $c) {
            $insCat->execute([$c['id'], $c['name'], $c['banglaName'], $c['iconName'], $c['description']]);
        }
        $insSrv = $pdo->prepare("INSERT IGNORE INTO services (service_code, name, bangla_name, category_id, price, estimated_delivery_time, description, instructions, icon, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $getId  = $pdo->prepare("SELECT id FROM services WHERE service_code = ?");
        $hasFld = $pdo->prepare("SELECT COUNT(*) FROM service_form_fields WHERE service_id = ?");
        $insFld = $pdo->prepare("INSERT INTO service_form_fields (service_id, field_key, label, bangla_label, field_type, is_required, placeholder, options_json, help_text, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        foreach (($data['services'] ?? []) as $s) {
            $insSrv->execute([
                $s['serviceCode'], $s['name'], $s['banglaName'], $s['categoryId'], $s['price'],
                $s['estimatedDeliveryTime'] ?: '১৫-৩০ মিনিট', $s['description'], $s['instructions'], $s['icon'], $s['status']
            ]);
            $getId->execute([$s['serviceCode']]);
            $sid = (int)$getId->fetchColumn();
            if ($sid <= 0) { continue; }
            $hasFld->execute([$sid]);
            if ((int)$hasFld->fetchColumn() > 0) { continue; }
            $i = 0;
            foreach (($s['fields'] ?? []) as $f) {
                $insFld->execute([
                    $sid, $f['key'], $f['label'], $f['banglaLabel'], $f['type'], $f['required'] ? 1 : 0,
                    $f['placeholder'], !empty($f['options']) ? json_encode($f['options'], JSON_UNESCAPED_UNICODE) : null,
                    $f['helpText'], $i++
                ]);
            }
        }
    } catch (Throwable $e) {
        error_log('[DigiSeba seed] default services failed: ' . $e->getMessage());
    }
}
