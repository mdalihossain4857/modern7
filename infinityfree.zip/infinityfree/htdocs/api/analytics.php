<?php
/**
 * DigiSeba BD - Authoritative Analytics & Visitor Telemetry API
 * Location: htdocs/api/analytics.php
 */

declare(strict_types=1);

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/security.php';

$pdo = getDbConnection();
$method = $_SERVER['REQUEST_METHOD'];
$action = trim((string)($_GET['action'] ?? 'summary'));

// 1. First-Party Anonymous Visitor Telemetry Tracking (Public)
if ($action === 'track_view' && $method === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true) ?: [];
    $pageUrl = sanitize(substr((string)($data['url'] ?? '/'), 0, 150));
    $referrer = sanitize(substr((string)($data['referrer'] ?? ''), 0, 150));

    $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
    $deviceType = (preg_match('/(mobile|android|iphone|ipad)/i', $ua)) ? 'mobile' : 'desktop';
    $visitorHash = hash('sha256', ($_SERVER['REMOTE_ADDR'] ?? '127.0.0.1') . date('Y-m-d'));

    try {
        $stmt = $pdo->prepare("INSERT INTO page_views (page_url, referrer, device_type, visitor_hash, created_at) VALUES (?, ?, ?, ?, NOW())");
        $stmt->execute([$pageUrl, $referrer, $deviceType, $visitorHash]);
        jsonResponse(['success' => true]);
    } catch (Exception $e) {
        jsonResponse(['success' => false], 200);
    }
}

// 2. Authoritative Analytics Summary (Admin Guarded)
if ($action === 'summary') {
    $admin = requireAdmin();

    try {
        $totalUsers = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role = 'customer'")->fetchColumn();
        $activeUsers = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role = 'customer' AND status = 'active'")->fetchColumn();

        $totalOrders = (int)$pdo->query("SELECT COUNT(*) FROM orders")->fetchColumn();
        $completedOrders = (int)$pdo->query("SELECT COUNT(*) FROM orders WHERE status = 'completed'")->fetchColumn();
        $pendingOrders = (int)$pdo->query("SELECT COUNT(*) FROM orders WHERE status IN ('pending', 'processing')")->fetchColumn();
        $refundedOrders = (int)$pdo->query("SELECT COUNT(*) FROM orders WHERE status = 'refunded'")->fetchColumn();

        $rechargeReceived = (float)($pdo->query("SELECT SUM(amount) FROM recharge_requests WHERE status = 'approved'")->fetchColumn() ?: 0.0);
        $serviceRevenue = (float)($pdo->query("SELECT SUM(service_price) FROM orders WHERE status = 'completed'")->fetchColumn() ?: 0.0);
        $totalRefunds = (float)($pdo->query("SELECT SUM(service_price) FROM orders WHERE status = 'refunded'")->fetchColumn() ?: 0.0);
        $walletLiability = (float)($pdo->query("SELECT SUM(balance) FROM wallets")->fetchColumn() ?: 0.0);

        $averageOrderValue = $completedOrders > 0 ? ($serviceRevenue / $completedOrders) : 0.0;

        jsonResponse([
            'success' => true,
            'metrics' => [
                'totalUsers' => $totalUsers,
                'activeUsers' => $activeUsers,
                'totalOrders' => $totalOrders,
                'completedOrders' => $completedOrders,
                'pendingOrders' => $pendingOrders,
                'refundedOrders' => $refundedOrders,
                'rechargeReceived' => $rechargeReceived,
                'serviceRevenue' => $serviceRevenue,
                'totalRefunds' => $totalRefunds,
                'walletLiability' => $walletLiability,
                'averageOrderValue' => round($averageOrderValue, 2),
                'completionRate' => $totalOrders > 0 ? round(($completedOrders / $totalOrders) * 100) : 0
            ]
        ]);
    } catch (Exception $e) {
        error_log("Analytics error: " . $e->getMessage());
        jsonResponse(['success' => false, 'message' => 'অ্যানালিটিক্স ডাটা লোড করতে ব্যর্থ হয়েছে'], 500);
    }
}
