<?php
/**
 * DigiSeba BD - Master REST API Router for InfinityFree
 * Location: htdocs/api/index.php
 *
 * Central controller handling all customer and admin REST requests.
 * Uses PDO prepared statements, atomic transactions, CSRF validation, and strict RBAC.
 */

declare(strict_types=1);

require_once __DIR__ . '/config/security.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/notifications.php';

$method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');

// Parse route from query string or request URI
$route = trim((string)($_GET['route'] ?? ''));
if ($route === '') {
    $uri = (string)parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
    $route = (string)preg_replace('#^.*/api/#', '', $uri);
}
$route = trim($route, '/');
// Normalize by stripping optional .php extension
$route = (string)preg_replace('/\.php$/i', '', $route);
if ($route === 'index') {
    $route = trim((string)($_GET['action'] ?? ''));
}

// Read JSON input body if present
$inputRaw = file_get_contents('php://input');
$body = !empty($inputRaw) ? (json_decode($inputRaw, true) ?: []) : [];
if (empty($body) && !empty($_POST)) {
    $body = $_POST;
}

// -----------------------------------------------------------------------------
// 1. SYSTEM HEALTH, FILES, BACKUP & ANALYTICS DELEGATION
// -----------------------------------------------------------------------------
if ($route === 'health') {
    require __DIR__ . '/health.php';
    exit;
}

if ($route === 'files') {
    require __DIR__ . '/files.php';
    exit;
}

if ($route === 'backup' || str_starts_with($route, 'backup/')) {
    require __DIR__ . '/backup.php';
    exit;
}

if ($route === 'analytics' || str_starts_with($route, 'analytics/')) {
    require __DIR__ . '/analytics.php';
    exit;
}

// -----------------------------------------------------------------------------
// 2. CSRF TOKEN ISSUANCE & PERMANENT LOGOUT (Does not require DB to destroy session)
// -----------------------------------------------------------------------------
if ($route === 'auth/csrf' && $method === 'GET') {
    jsonResponse([
        'success'    => true,
        'csrf_token' => generateCsrfToken()
    ]);
}

if ($route === 'auth/logout' || $route === 'admin/auth/logout') {
    if ($method !== 'POST') {
        jsonResponse([
            'success' => false,
            'message' => 'লগআউটের জন্য POST মেথড ব্যবহার করা আবশ্যক (HTTP 405 Method Not Allowed)।'
        ], 405);
    }

    // Enforce CSRF verification when an active session is being terminated
    if (!empty($_SESSION['user_id']) && !empty($_SESSION['csrf_token'])) {
        validateCsrf($body);
    }

    destroyAuthSession();

    jsonResponse([
        'success'       => true,
        'authenticated' => false,
        'message'       => 'সফলভাবে লগআউট হয়েছেন এবং সার্ভার সেশন স্থায়ীভাবে সমাপ্ত করা হয়েছে।'
    ]);
}

// Connect to MySQL Database for data-backed endpoints
$pdo = getDbConnection();

// -----------------------------------------------------------------------------
// 3. AUTHENTICATION (CUSTOMER & ADMIN — REAL MYSQL + BCRYPT + SESSION)
// -----------------------------------------------------------------------------
if ($route === 'auth/login' || $route === 'admin/auth/login') {
    if ($method !== 'POST') {
        jsonResponse([
            'success' => false,
            'message' => 'লগইনের জন্য POST মেথড আবশ্যক (HTTP 405)।'
        ], 405);
    }

    $clientIp = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    if (!checkRateLimit('login_' . $clientIp, 10, 900)) {
        jsonResponse([
            'success' => false,
            'message' => 'অতিরিক্ত ব্যর্থ চেষ্টার কারণে সাময়িকভাবে লগইন স্থগিত রয়েছে। ১৫ মিনিট পর চেষ্টা করুন।'
        ], 429);
    }

    $identifier = trim((string)($body['phone'] ?? $body['emailOrUsername'] ?? $body['identifier'] ?? $body['email'] ?? ''));
    $password = (string)($body['password'] ?? '');

    if ($identifier === '' || $password === '') {
        jsonResponse(['success' => false, 'message' => 'লগইন করতে মোবাইল/ইমেইল এবং পাসওয়ার্ড প্রদান করুন।'], 400);
    }

    try {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE phone = ? OR email = ? LIMIT 1");
        $stmt->execute([$identifier, $identifier]);
        $user = $stmt->fetch();
    } catch (PDOException $e) {
        error_log("Login query failed: " . $e->getMessage());
        jsonResponse([
            'success' => false,
            'message' => 'ডাটাবেজে users টেবিল পাওয়া যায়নি। অনুগ্রহ করে প্রথমে phpMyAdmin এ schema.sql ইমপোর্ট করুন।'
        ], 503);
    }

    if (!$user || empty($user['password_hash']) || !password_verify($password, (string)$user['password_hash'])) {
        jsonResponse(['success' => false, 'message' => 'ভুল মোবাইল/ইমেইল অথবা পাসওয়ার্ড। অনুগ্রহ করে সঠিক তথ্য দিন।'], 401);
    }

    if (($user['status'] ?? 'active') === 'suspended') {
        jsonResponse(['success' => false, 'message' => 'আপনার অ্যাকাউন্টটি সাময়িকভাবে স্থগিত করা হয়েছে। সাপোর্টে যোগাযোগ করুন।'], 403);
    }

    if ($route === 'admin/auth/login' && !in_array($user['role'], ['admin', 'super_admin', 'staff'], true)) {
        jsonResponse(['success' => false, 'message' => 'এই অ্যাকাউন্টে অ্যাডমিন প্যানেলে প্রবেশের অধিকার নেই (HTTP 403)।'], 403);
    }

    // Regenerate session ID to prevent session fixation
    session_regenerate_id(true);
    resetRateLimit('login_' . $clientIp);

    $_SESSION['user_id'] = (int)$user['id'];
    $_SESSION['user_role'] = (string)$user['role'];
    $_SESSION['user_name'] = (string)$user['name'];
    $_SESSION['authenticated_at'] = time();
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

    $walletBalance = 0.0;
    try {
        $stmtWal = $pdo->prepare("SELECT balance FROM wallets WHERE user_id = ? LIMIT 1");
        $stmtWal->execute([$user['id']]);
        $walletBalance = (float)($stmtWal->fetchColumn() ?: 0.0);
    } catch (PDOException $e) {
        $walletBalance = 0.0;
    }

    $userPayload = [
        'id'            => (string)$user['id'],
        'name'          => (string)$user['name'],
        'phone'         => (string)$user['phone'],
        'email'         => (string)$user['email'],
        'role'          => (string)$user['role'],
        'roleId'        => (string)($user['role_id'] ?? ($user['role'] === 'admin' ? 'role_super_admin' : '')),
        'roleName'      => in_array($user['role'], ['admin', 'super_admin'], true) ? 'Super Admin' : ($user['role'] === 'staff' ? 'Staff' : 'Customer'),
        'status'        => (string)$user['status'],
        'walletBalance' => $walletBalance,
        'createdAt'     => (string)($user['created_at'] ?? date('Y-m-d H:i:s'))
    ];

    jsonResponse([
        'success'       => true,
        'authenticated' => true,
        'message'       => 'লগইন সফল হয়েছে',
        'csrf_token'    => $_SESSION['csrf_token'],
        'user'          => $userPayload,
        'data'          => [
            'user'  => $userPayload,
            'staff' => $userPayload
        ]
    ]);
}

if ($route === 'auth/register') {
    if ($method !== 'POST') {
        jsonResponse(['success' => false, 'message' => 'রেজিস্ট্রেশনের জন্য POST মেথড আবশ্যক।'], 405);
    }

    $clientIp = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    if (!checkRateLimit('register_' . $clientIp, 8, 900)) {
        jsonResponse(['success' => false, 'message' => 'অতিরিক্ত চেষ্টার কারণে সাময়িকভাবে রেজিস্ট্রেশন স্থগিত রয়েছে। পরে চেষ্টা করুন।'], 429);
    }

    $name     = sanitize((string)($body['name'] ?? ''));
    $phone    = preg_replace('/[^0-9+]/', '', trim((string)($body['phone'] ?? '')));
    $email    = strtolower(trim((string)($body['email'] ?? '')));
    $password = (string)($body['password'] ?? '');

    if ($name === '' || $phone === '' || $email === '' || $password === '') {
        jsonResponse(['success' => false, 'message' => 'নাম, মোবাইল নম্বর, ইমেইল এবং পাসওয়ার্ড পূরণ করা আবশ্যক।'], 400);
    }

    if (strlen($phone) < 11) {
        jsonResponse(['success' => false, 'message' => 'সঠিক ১১ ডিজিটের মোবাইল নম্বর প্রদান করুন।'], 400);
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        jsonResponse(['success' => false, 'message' => 'সঠিক ইমেইল ঠিকানা প্রদান করুন।'], 400);
    }

    if (strlen($password) < 8) {
        jsonResponse(['success' => false, 'message' => 'পাসওয়ার্ড কমপক্ষে ৮ অক্ষরের হতে হবে।'], 400);
    }

    $stmtDup = $pdo->prepare("SELECT id FROM users WHERE phone = ? OR email = ? LIMIT 1");
    $stmtDup->execute([$phone, $email]);
    if ($stmtDup->fetchColumn()) {
        jsonResponse(['success' => false, 'message' => 'এই মোবাইল নম্বর বা ইমেইল দিয়ে ইতিমধ্যে একটি অ্যাকাউন্ট রয়েছে। অনুগ্রহ করে লগইন করুন।'], 409);
    }

    $passwordHash = password_hash($password, PASSWORD_BCRYPT);

    $pdo->beginTransaction();
    try {
        $stmtIns = $pdo->prepare("INSERT INTO users (name, phone, email, password_hash, role, status) VALUES (?, ?, ?, ?, 'customer', 'active')");
        $stmtIns->execute([$name, $phone, $email, $passwordHash]);
        $newUserId = (int)$pdo->lastInsertId();

        $stmtWal = $pdo->prepare("INSERT INTO wallets (user_id, balance) VALUES (?, 0.00)");
        $stmtWal->execute([$newUserId]);

        $pdo->commit();
    } catch (PDOException $e) {
        $pdo->rollBack();
        error_log("Registration failed: " . $e->getMessage());
        jsonResponse(['success' => false, 'message' => 'অ্যাকাউন্ট তৈরি করতে সমস্যা হয়েছে। অনুগ্রহ করে আবার চেষ্টা করুন।'], 500);
    }

    session_regenerate_id(true);
    $_SESSION['user_id'] = $newUserId;
    $_SESSION['user_role'] = 'customer';
    $_SESSION['user_name'] = $name;
    $_SESSION['authenticated_at'] = time();
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

    $userPayload = [
        'id'            => (string)$newUserId,
        'name'          => $name,
        'phone'         => $phone,
        'email'         => $email,
        'role'          => 'customer',
        'status'        => 'active',
        'walletBalance' => 0.00,
        'createdAt'     => date('Y-m-d H:i:s')
    ];

    jsonResponse([
        'success'       => true,
        'authenticated' => true,
        'message'       => 'অ্যাকাউন্ট সফলভাবে তৈরি হয়েছে এবং লগইন সম্পন্ন হয়েছে।',
        'csrf_token'    => $_SESSION['csrf_token'],
        'user'          => $userPayload,
        'data'          => ['user' => $userPayload]
    ], 201);
}

if ($route === 'auth/me' || $route === 'admin/auth/me' || $route === 'profile/get') {
    $rawUserId = $_SESSION['user_id'] ?? null;
    $sessionUserId = is_numeric($rawUserId) ? (int)$rawUserId : 0;

    if ($sessionUserId <= 0) {
        jsonResponse([
            'success'       => false,
            'authenticated' => false,
            'message'       => 'লগইন করা নেই'
        ], 401);
    }

    $stmt = $pdo->prepare("SELECT id, name, phone, email, role, role_id, status, avatar, created_at FROM users WHERE id = ? LIMIT 1");
    $stmt->execute([$sessionUserId]);
    $user = $stmt->fetch();

    if (!$user || ($user['status'] ?? 'active') === 'suspended') {
        destroyAuthSession();
        jsonResponse([
            'success'       => false,
            'authenticated' => false,
            'message'       => 'সেশন অবৈধ বা অ্যাকাউন্ট স্থগিত করা হয়েছে।'
        ], 401);
    }

    // Keep session role synchronized with database
    $_SESSION['user_role'] = (string)$user['role'];
    $_SESSION['user_name'] = (string)$user['name'];

    if ($route === 'admin/auth/me' && !in_array($user['role'], ['admin', 'super_admin', 'staff'], true)) {
        jsonResponse([
            'success'       => false,
            'authenticated' => true,
            'authorized'    => false,
            'message'       => 'অ্যাডমিন প্যানেলে প্রবেশের অনুমতি নেই (HTTP 403)।'
        ], 403);
    }

    $balance = 0.0;
    try {
        $stmtWal = $pdo->prepare("SELECT balance FROM wallets WHERE user_id = ? LIMIT 1");
        $stmtWal->execute([$user['id']]);
        $balance = (float)($stmtWal->fetchColumn() ?: 0.0);
    } catch (PDOException $e) {
        $balance = 0.0;
    }

    $userPayload = [
        'id'            => (string)$user['id'],
        'name'          => (string)$user['name'],
        'phone'         => (string)$user['phone'],
        'email'         => (string)$user['email'],
        'role'          => (string)$user['role'],
        'roleId'        => (string)($user['role_id'] ?? ($user['role'] === 'admin' ? 'role_super_admin' : '')),
        'roleName'      => in_array($user['role'], ['admin', 'super_admin'], true) ? 'Super Admin' : ($user['role'] === 'staff' ? 'Staff' : 'Customer'),
        'status'        => (string)$user['status'],
        'avatar'        => $user['avatar'],
        'walletBalance' => $balance,
        'createdAt'     => (string)$user['created_at']
    ];

    jsonResponse([
        'success'       => true,
        'authenticated' => true,
        'csrf_token'    => generateCsrfToken(),
        'user'          => $userPayload,
        'data'          => ['user' => $userPayload]
    ]);
}

if ($route === 'auth/change_password' && $method === 'POST') {
    $user = requireAuth();
    validateCsrf($body);

    $currentPass = (string)($body['currentPassword'] ?? '');
    $newPass     = (string)($body['newPassword'] ?? '');

    if (strlen($newPass) < 8) {
        jsonResponse(['success' => false, 'message' => 'নতুন পাসওয়ার্ড কমপক্ষে ৮ অক্ষরের হতে হবে'], 400);
    }

    $stmt = $pdo->prepare("SELECT password_hash FROM users WHERE id = ? LIMIT 1");
    $stmt->execute([$user['id']]);
    $hash = $stmt->fetchColumn();

    if (!$hash || !password_verify($currentPass, (string)$hash)) {
        jsonResponse(['success' => false, 'message' => 'বর্তমান পাসওয়ার্ডটি সঠিক নয়'], 400);
    }

    $newHash = password_hash($newPass, PASSWORD_BCRYPT);
    $stmtUp = $pdo->prepare("UPDATE users SET password_hash = ? WHERE id = ?");
    $stmtUp->execute([$newHash, $user['id']]);

    session_regenerate_id(true);

    jsonResponse([
        'success'    => true,
        'csrf_token' => generateCsrfToken(),
        'message'    => 'পাসওয়ার্ড সফলভাবে পরিবর্তিত হয়েছে'
    ]);
}

if ($route === 'profile/update' && $method === 'POST') {
    $user = requireAuth();
    validateCsrf($body);

    $name  = sanitize((string)($body['name'] ?? ''));
    $email = sanitize((string)($body['email'] ?? ''));
    $phone = sanitize((string)($body['phone'] ?? ''));

    if ($name === '' || $email === '' || $phone === '') {
        jsonResponse(['success' => false, 'message' => 'নাম, ইমেইল ও মোবাইল নম্বর আবশ্যক'], 400);
    }

    $stmt = $pdo->prepare("UPDATE users SET name = ?, email = ?, phone = ? WHERE id = ?");
    $stmt->execute([$name, $email, $phone, $user['id']]);
    $_SESSION['user_name'] = $name;

    jsonResponse(['success' => true, 'message' => 'প্রোফাইল সফলভাবে আপডেট হয়েছে']);
}

// -----------------------------------------------------------------------------
// 4. SERVICES & CATEGORIES (PUBLIC & CUSTOMER)
// -----------------------------------------------------------------------------
if (($route === 'services' || $route === 'services/list') && $method === 'GET') {
    $stmt = $pdo->query("SELECT * FROM services WHERE status != 'archived' ORDER BY id ASC");
    $services = $stmt->fetchAll();

    $stmtFields = $pdo->query("SELECT * FROM service_form_fields ORDER BY sort_order ASC");
    $fields = $stmtFields->fetchAll();

    $fieldsByService = [];
    foreach ($fields as $f) {
        $fieldsByService[$f['service_id']][] = [
            'id'          => $f['field_key'],
            'label'       => $f['label'],
            'banglaLabel' => $f['bangla_label'],
            'type'        => $f['field_type'],
            'required'    => (bool)$f['is_required'],
            'placeholder' => $f['placeholder'],
            'options'     => $f['options_json'] ? json_decode($f['options_json'], true) : [],
            'helpText'    => $f['help_text']
        ];
    }

    $response = [];
    foreach ($services as $s) {
        $response[] = [
            'id'                    => (string)$s['id'],
            'serviceCode'           => $s['service_code'],
            'name'                  => $s['name'],
            'banglaName'            => $s['bangla_name'],
            'categoryId'            => $s['category_id'],
            'description'           => $s['description'],
            'price'                 => (float)$s['price'],
            'estimatedDeliveryTime' => $s['estimated_delivery_time'],
            'instructions'          => $s['instructions'],
            'icon'                  => $s['icon'],
            'status'                => $s['status'],
            'orderCount'            => (int)$s['order_count'],
            'fields'                => $fieldsByService[$s['id']] ?? []
        ];
    }

    jsonResponse([
        'success'  => true,
        'services' => $response,
        'data'     => ['services' => $response]
    ]);
}

if ($route === 'services/detail' && $method === 'GET') {
    $id = (int)($_GET['id'] ?? 0);
    $stmt = $pdo->prepare("SELECT * FROM services WHERE id = ?");
    $stmt->execute([$id]);
    $s = $stmt->fetch();
    if (!$s) {
        jsonResponse(['success' => false, 'message' => 'সার্ভিস পাওয়া যায়নি'], 404);
    }

    $stmtF = $pdo->prepare("SELECT * FROM service_form_fields WHERE service_id = ? ORDER BY sort_order ASC");
    $stmtF->execute([$id]);
    $fields = [];
    foreach ($stmtF->fetchAll() as $f) {
        $fields[] = [
            'id'          => $f['field_key'],
            'label'       => $f['label'],
            'banglaLabel' => $f['bangla_label'],
            'type'        => $f['field_type'],
            'required'    => (bool)$f['is_required'],
            'placeholder' => $f['placeholder'],
            'options'     => $f['options_json'] ? json_decode($f['options_json'], true) : [],
            'helpText'    => $f['help_text']
        ];
    }

    $serviceItem = [
        'id'                    => (string)$s['id'],
        'serviceCode'           => $s['service_code'],
        'name'                  => $s['name'],
        'banglaName'            => $s['bangla_name'],
        'categoryId'            => $s['category_id'],
        'description'           => $s['description'],
        'price'                 => (float)$s['price'],
        'estimatedDeliveryTime' => $s['estimated_delivery_time'],
        'instructions'          => $s['instructions'],
        'icon'                  => $s['icon'],
        'status'                => $s['status'],
        'orderCount'            => (int)$s['order_count'],
        'fields'                => $fields
    ];

    jsonResponse(['success' => true, 'service' => $serviceItem, 'data' => ['service' => $serviceItem]]);
}

if (($route === 'categories' || $route === 'services/categories') && $method === 'GET') {
    $stmt = $pdo->query("SELECT id, name, bangla_name AS banglaName, icon_name AS iconName, description FROM service_categories ORDER BY id ASC");
    $cats = $stmt->fetchAll();
    jsonResponse(['success' => true, 'categories' => $cats, 'data' => ['categories' => $cats]]);
}

// -----------------------------------------------------------------------------
// 5. CUSTOMER ORDERS (PROTECTED BY SERVER SESSION + ATOMIC WALLET DEBIT)
// -----------------------------------------------------------------------------
if (($route === 'orders' || $route === 'orders/list') && $method === 'GET') {
    $user = requireAuth();
    $stmt = $pdo->prepare("SELECT * FROM orders WHERE user_id = ? ORDER BY id DESC");
    $stmt->execute([$user['id']]);
    $orders = $stmt->fetchAll();

    $formatted = [];
    foreach ($orders as $o) {
        $formatted[] = [
            'id'             => (string)$o['id'],
            'orderNumber'    => $o['order_number'],
            'userId'         => (string)$o['user_id'],
            'userName'       => $user['name'],
            'serviceId'      => (string)$o['service_id'],
            'serviceName'    => $o['service_name'],
            'servicePrice'   => (float)$o['service_price'],
            'formData'       => json_decode($o['form_values_json'] ?: '{}', true),
            'status'         => $o['status'],
            'adminNote'      => $o['admin_note'],
            'deliverableUrl' => $o['deliverable_file'] ? '/api/files?file=' . urlencode($o['deliverable_file']) : null,
            'createdAt'      => $o['created_at'],
            'updatedAt'      => $o['updated_at']
        ];
    }

    jsonResponse(['success' => true, 'orders' => $formatted, 'data' => ['orders' => $formatted]]);
}

if ($route === 'orders/detail' && $method === 'GET') {
    $user = requireAuth();
    $orderId = (int)($_GET['id'] ?? 0);
    $stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ? AND user_id = ?");
    $stmt->execute([$orderId, $user['id']]);
    $o = $stmt->fetch();

    if (!$o) {
        jsonResponse(['success' => false, 'message' => 'অর্ডার পাওয়া যায়নি'], 404);
    }

    $orderItem = [
        'id'             => (string)$o['id'],
        'orderNumber'    => $o['order_number'],
        'userId'         => (string)$o['user_id'],
        'serviceId'      => (string)$o['service_id'],
        'serviceName'    => $o['service_name'],
        'servicePrice'   => (float)$o['service_price'],
        'formData'       => json_decode($o['form_values_json'] ?: '{}', true),
        'status'         => $o['status'],
        'adminNote'      => $o['admin_note'],
        'deliverableUrl' => $o['deliverable_file'] ? '/api/files?file=' . urlencode($o['deliverable_file']) : null,
        'createdAt'      => $o['created_at'],
        'updatedAt'      => $o['updated_at']
    ];

    jsonResponse(['success' => true, 'order' => $orderItem, 'data' => ['order' => $orderItem]]);
}

if (($route === 'orders/create' || ($route === 'orders' && $method === 'POST'))) {
    $user = requireAuth();
    validateCsrf($body);

    $serviceId = (int)($body['serviceId'] ?? $body['service_id'] ?? 0);
    $formData  = $body['formData'] ?? $body['form_values'] ?? [];
    $serviceCode = trim((string)($body['serviceCode'] ?? $body['service_code'] ?? ''));

    $pdo->beginTransaction();
    try {
        // Prefer the stable service_code (frontend catalog ids are not DB ids), fall back to numeric id
        if ($serviceCode !== '') {
            $stmtSrv = $pdo->prepare("SELECT id, name, bangla_name, price, status FROM services WHERE service_code = ?");
            $stmtSrv->execute([$serviceCode]);
        } else {
            $stmtSrv = $pdo->prepare("SELECT id, name, bangla_name, price, status FROM services WHERE id = ?");
            $stmtSrv->execute([$serviceId]);
        }
        $srv = $stmtSrv->fetch();

        // First order on a fresh database: make sure the default catalog exists, then look again
        if (!$srv && $serviceCode !== '') {
            if ($pdo->inTransaction()) { $pdo->commit(); }
            ensureDefaultServices($pdo);
            $pdo->beginTransaction();
            $stmtSrv = $pdo->prepare("SELECT id, name, bangla_name, price, status FROM services WHERE service_code = ?");
            $stmtSrv->execute([$serviceCode]);
            $srv = $stmtSrv->fetch();
        }

        if (!$srv || $srv['status'] !== 'active') {
            $pdo->rollBack();
            jsonResponse(['success' => false, 'message' => 'সার্ভিসটি পাওয়া যায়নি বা বর্তমানে সাময়িকভাবে বন্ধ আছে।'], 404);
        }

        $price = (float)$srv['price'];

        $stmtWal = $pdo->prepare("SELECT balance FROM wallets WHERE user_id = ? FOR UPDATE");
        $stmtWal->execute([$user['id']]);
        $currentBalance = (float)($stmtWal->fetchColumn() ?: 0.0);

        if ($currentBalance < $price) {
            $pdo->rollBack();
            jsonResponse([
                'success' => false,
                'message' => 'আপনার ওয়ালেটে পর্যাপ্ত ব্যালেন্স নেই।'
            ], 400);
        }

        $stmtChk = $pdo->prepare("SELECT COUNT(*) FROM orders WHERE order_number = ?");
        do {
            $orderNumber = 'ORD-' . date('Y') . '-' . mt_rand(10000, 99999);
            $stmtChk->execute([$orderNumber]);
        } while ((int)$stmtChk->fetchColumn() > 0);
        $newBalance = $currentBalance - $price;

        $stmtDeduct = $pdo->prepare("UPDATE wallets SET balance = ? WHERE user_id = ?");
        $stmtDeduct->execute([$newBalance, $user['id']]);

        $stmtOrder = $pdo->prepare("INSERT INTO orders (order_number, user_id, service_id, service_name, service_price, form_values_json, status) VALUES (?, ?, ?, ?, ?, ?, 'pending')");
        $stmtOrder->execute([
            $orderNumber,
            $user['id'],
            $srv['id'],
            $srv['bangla_name'],
            $price,
            json_encode($formData, JSON_UNESCAPED_UNICODE)
        ]);
        $orderId = (int)$pdo->lastInsertId();

        $stmtLedger = $pdo->prepare("INSERT INTO wallet_ledger (user_id, amount, type, category, reference_id, description, balance_after) VALUES (?, ?, 'debit', 'order', ?, ?, ?)");
        $desc = "Payment for {$srv['bangla_name']} ({$orderNumber})";
        $stmtLedger->execute([$user['id'], $price, $orderNumber, $desc, $newBalance]);

        $stmtInc = $pdo->prepare("UPDATE services SET order_count = order_count + 1 WHERE id = ?");
        $stmtInc->execute([$srv['id']]);

        $pdo->commit();

        notifyAdmins(
            $pdo, 'warning', 'নতুন অর্ডার এসেছে',
            "{$user['name']} — {$srv['bangla_name']} (" . formatTaka($price) . ") — অর্ডার নম্বর {$orderNumber}",
            '/admin/orders'
        );
        createNotification(
            $pdo, (int)$user['id'], 'success', 'অর্ডার জমা হয়েছে',
            "অর্ডার {$orderNumber} ({$srv['bangla_name']}) সফলভাবে জমা হয়েছে। ওয়ালেট থেকে " . formatTaka($price) . " কাটা হয়েছে।",
            '/orders'
        );

        $orderPayload = [
            'id'           => (string)$orderId,
            'orderNumber'  => $orderNumber,
            'balanceAfter' => $newBalance
        ];

        jsonResponse([
            'success' => true,
            'message' => 'অর্ডার সফলভাবে জমা হয়েছে।',
            'order'   => $orderPayload,
            'data'    => ['order' => $orderPayload]
        ]);
    } catch (Exception $e) {
        $pdo->rollBack();
        error_log("Order creation exception: " . $e->getMessage());
        jsonResponse(['success' => false, 'message' => 'অর্ডার প্রক্রিয়াকরণে সমস্যা হয়েছে।'], 500);
    }
}

if ($route === 'orders/reply' && $method === 'POST') {
    $user = requireAuth();
    validateCsrf($body);

    $orderId      = (int)($body['orderId'] ?? 0);
    $replyMessage = sanitize((string)($body['replyMessage'] ?? ''));

    $stmt = $pdo->prepare("SELECT id, admin_note, status FROM orders WHERE id = ? AND user_id = ?");
    $stmt->execute([$orderId, $user['id']]);
    $ord = $stmt->fetch();

    if (!$ord) {
        jsonResponse(['success' => false, 'message' => 'অর্ডার পাওয়া যায়নি'], 404);
    }

    $updatedNote = ($ord['admin_note'] ? $ord['admin_note'] . "\n" : '') . "[গ্রাহকের বার্তা]: " . $replyMessage;
    $nextStatus = $ord['status'] === 'needs_info' ? 'processing' : $ord['status'];

    $stmtUp = $pdo->prepare("UPDATE orders SET admin_note = ?, status = ?, updated_at = NOW() WHERE id = ?");
    $stmtUp->execute([$updatedNote, $nextStatus, $orderId]);

    notifyAdmins($pdo, 'info', 'গ্রাহকের বার্তা', "{$user['name']} অর্ডার #{$orderId}-এ বার্তা পাঠিয়েছেন: " . notifText($replyMessage, 120), '/admin/orders');

    jsonResponse(['success' => true, 'message' => 'আপনার বার্তা সফলভাবে প্রেরণ করা হয়েছে']);
}

// -----------------------------------------------------------------------------
// 6. WALLET, RECHARGE & SUPPORT TICKETS (CUSTOMER — PROTECTED)
// -----------------------------------------------------------------------------
if (($route === 'wallet/my_wallet' || $route === 'wallet/summary' || $route === 'wallet/transactions') && $method === 'GET') {
    $user = requireAuth();

    $stmtBal = $pdo->prepare("SELECT balance FROM wallets WHERE user_id = ?");
    $stmtBal->execute([$user['id']]);
    $balance = (float)($stmtBal->fetchColumn() ?: 0.0);

    $stmtRch = $pdo->prepare("SELECT COALESCE(SUM(amount), 0) FROM recharge_requests WHERE user_id = ? AND status = 'approved'");
    $stmtRch->execute([$user['id']]);
    $totalRecharge = (float)$stmtRch->fetchColumn();

    $stmtPend = $pdo->prepare("SELECT COALESCE(SUM(amount), 0) FROM recharge_requests WHERE user_id = ? AND status = 'pending'");
    $stmtPend->execute([$user['id']]);
    $pendingRecharge = (float)$stmtPend->fetchColumn();

    $stmtSpend = $pdo->prepare("SELECT COALESCE(SUM(service_price), 0) FROM orders WHERE user_id = ? AND status = 'completed'");
    $stmtSpend->execute([$user['id']]);
    $totalSpending = (float)$stmtSpend->fetchColumn();

    $stmtLed = $pdo->prepare("SELECT id, user_id AS userId, amount, type, category, reference_id AS referenceId, description, balance_after AS balanceAfter, created_at AS createdAt FROM wallet_ledger WHERE user_id = ? ORDER BY id DESC LIMIT 100");
    $stmtLed->execute([$user['id']]);
    $rawLedger = $stmtLed->fetchAll();
    $ledger = [];
    foreach ($rawLedger as $l) {
        $ledger[] = [
            'id'           => (string)$l['id'],
            'userId'       => (string)$l['userId'],
            'amount'       => (float)$l['amount'],
            'type'         => $l['type'],
            'category'     => $l['category'],
            'referenceId'  => $l['referenceId'],
            'description'  => $l['description'],
            'balanceAfter' => (float)$l['balanceAfter'],
            'createdAt'    => $l['createdAt'],
        ];
    }

    $summary = [
        'balance'         => $balance,
        'totalRecharge'   => $totalRecharge,
        'totalSpending'   => $totalSpending,
        'pendingRecharge' => $pendingRecharge
    ];

    jsonResponse([
        'success' => true,
        'balance' => $balance,
        'summary' => $summary,
        'ledger'  => $ledger,
        'data'    => [
            'summary' => $summary,
            'ledger'  => $ledger
        ]
    ]);
}

if ($route === 'recharges/list' && $method === 'GET') {
    $user = requireAuth();
    $stmt = $pdo->prepare("SELECT id, user_id AS userId, method, amount, sender_number AS senderNumber, trx_id AS trxId, status, rejection_reason AS rejectionReason, created_at AS createdAt, approved_at AS approvedAt FROM recharge_requests WHERE user_id = ? ORDER BY id DESC");
    $stmt->execute([$user['id']]);
    $rawList = $stmt->fetchAll();
    $list = [];
    foreach ($rawList as $r) {
        $list[] = [
            'id'              => (string)$r['id'],
            'userId'          => (string)$r['userId'],
            'userName'        => (string)$user['name'],
            'method'          => $r['method'],
            'amount'          => (float)$r['amount'],
            'senderNumber'    => $r['senderNumber'],
            'trxId'           => $r['trxId'],
            'status'          => $r['status'],
            'rejectionReason' => $r['rejectionReason'],
            'createdAt'       => $r['createdAt'],
            'approvedAt'      => $r['approvedAt'],
        ];
    }

    jsonResponse([
        'success'   => true,
        'recharges' => $list,
        'data'      => ['recharges' => $list]
    ]);
}

if (($route === 'wallet/recharge_request' || $route === 'recharges/create') && $method === 'POST') {
    $user = requireAuth();
    validateCsrf($body);

    $amount       = round((float)($body['amount'] ?? 0), 2);
    $payMethodRaw = trim((string)($body['method'] ?? 'bKash'));
    $methodMap    = ['bkash' => 'bKash', 'nagad' => 'Nagad', 'rocket' => 'Rocket', 'bank' => 'Bank'];
    $payMethod    = $methodMap[strtolower($payMethodRaw)] ?? '';
    $senderNumber = sanitize((string)($body['senderNumber'] ?? $body['sender_number'] ?? ''));
    $trxId        = strtoupper(sanitize((string)($body['trxId'] ?? $body['trx_id'] ?? '')));

    $minRecharge = 110.00;
    try {
        $stmtMin = $pdo->prepare("SELECT setting_value FROM site_settings WHERE setting_key = 'min_recharge' LIMIT 1");
        $stmtMin->execute();
        $minVal = $stmtMin->fetchColumn();
        if ($minVal !== false && (float)$minVal > 0) {
            $minRecharge = (float)$minVal;
        }
    } catch (Throwable $e) { /* keep default */ }

    if ($payMethod === '') {
        jsonResponse(['success' => false, 'message' => 'পেমেন্ট মাধ্যম সঠিক নয় (bKash / Nagad / Rocket / Bank)'], 400);
    }
    if ($amount < $minRecharge) {
        jsonResponse(['success' => false, 'message' => 'সর্বনিম্ন রিচার্জ পরিমাণ ' . number_format($minRecharge, 2) . ' টাকা'], 400);
    }
    if ($trxId === '' || strlen($trxId) < 5) {
        jsonResponse(['success' => false, 'message' => 'সঠিক ও পূর্ণাঙ্গ TrxID প্রদান করুন'], 400);
    }

    try {
        $stmt = $pdo->prepare("INSERT INTO recharge_requests (user_id, method, amount, sender_number, trx_id, status) VALUES (?, ?, ?, ?, ?, 'pending')");
        $stmt->execute([$user['id'], $payMethod, $amount, $senderNumber, $trxId]);
        $newId = (string)$pdo->lastInsertId();
    } catch (PDOException $e) {
        if ($e->getCode() == 23000) {
            jsonResponse(['success' => false, 'message' => 'এই TrxID দিয়ে ইতিমধ্যে রিকোয়েস্ট করা হয়েছে। ডুপ্লিকেট রিকোয়েস্ট গ্রহণযোগ্য নয়।'], 400);
        }
        error_log("Recharge exception: " . $e->getMessage());
        jsonResponse(['success' => false, 'message' => 'রিচার্জ সাবমিট করতে ব্যর্থ হয়েছে।'], 500);
    }

    // Notifications (never block the response)
    notifyAdmins(
        $pdo, 'warning', 'নতুন রিচার্জ রিকোয়েস্ট',
        "{$user['name']} — " . formatTaka($amount) . " ({$payMethod}), TrxID: {$trxId}। যাচাই করে অনুমোদন দিন।",
        '/admin/recharges'
    );
    createNotification(
        $pdo, (int)$user['id'], 'info', 'রিচার্জ রিকোয়েস্ট জমা হয়েছে',
        formatTaka($amount) . " ({$payMethod}) রিচার্জ রিকোয়েস্ট জমা হয়েছে। অ্যাডমিন যাচাই করলে ব্যালেন্স যুক্ত হবে।",
        '/recharges'
    );

    jsonResponse([
        'success' => true,
        'message' => 'রিচার্জ রিকোয়েস্ট সফলভাবে জমা হয়েছে। অ্যাডমিন ভেরিফাইয়ের পর ব্যালেন্স যুক্ত হবে।',
        'data'    => [
            'recharge' => [
                'id'           => $newId,
                'userId'       => (string)$user['id'],
                'userName'     => $user['name'],
                'method'       => $payMethod,
                'amount'       => $amount,
                'senderNumber' => $senderNumber,
                'trxId'        => $trxId,
                'status'       => 'pending',
                'createdAt'    => date('Y-m-d H:i:s')
            ]
        ]
    ]);
}

// -----------------------------------------------------------------------------
// 6b. NOTIFICATIONS (CUSTOMER & ADMIN — own notifications only)
// -----------------------------------------------------------------------------
if ($route === 'notifications/list' && $method === 'GET') {
    $user = requireAuth();
    $rows = [];
    try {
        $stmt = $pdo->prepare("SELECT id, type, title, message, link, is_read, created_at FROM notifications WHERE user_id = ? ORDER BY id DESC LIMIT 50");
        $stmt->execute([$user['id']]);
        $rows = $stmt->fetchAll();
    } catch (PDOException $e) {
        try { ensureNotificationsTable($pdo); } catch (Throwable $e2) { error_log('notif table: ' . $e2->getMessage()); }
        $rows = [];
    }
    $list = [];
    $unread = 0;
    foreach ($rows as $r) {
        $isRead = (int)$r['is_read'] === 1;
        if (!$isRead) { $unread++; }
        $list[] = [
            'id'        => (string)$r['id'],
            'type'      => (string)$r['type'],
            'title'     => (string)$r['title'],
            'message'   => (string)$r['message'],
            'link'      => $r['link'] !== null ? (string)$r['link'] : null,
            'read'      => $isRead,
            'createdAt' => (string)$r['created_at'],
        ];
    }
    jsonResponse(['success' => true, 'notifications' => $list, 'unreadCount' => $unread, 'data' => ['notifications' => $list, 'unreadCount' => $unread]]);
}

if ($route === 'notifications/read' && $method === 'POST') {
    $user = requireAuth();
    validateCsrf($body);
    $nid = (int)($body['id'] ?? $body['notificationId'] ?? 0);
    try {
        $stmt = $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?");
        $stmt->execute([$nid, $user['id']]);
    } catch (PDOException $e) {
        error_log('notif read: ' . $e->getMessage());
    }
    jsonResponse(['success' => true]);
}

if ($route === 'notifications/read_all' && $method === 'POST') {
    $user = requireAuth();
    validateCsrf($body);
    try {
        $stmt = $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ? AND is_read = 0");
        $stmt->execute([$user['id']]);
    } catch (PDOException $e) {
        error_log('notif read_all: ' . $e->getMessage());
    }
    jsonResponse(['success' => true]);
}

if ($route === 'tickets/list' && $method === 'GET') {
    $user = requireAuth();
    $stmt = $pdo->prepare("SELECT id, ticket_number AS ticketNumber, user_id AS userId, subject, status, priority, created_at AS createdAt FROM support_tickets WHERE user_id = ? ORDER BY id DESC");
    $stmt->execute([$user['id']]);
    $tickets = $stmt->fetchAll();
    jsonResponse(['success' => true, 'tickets' => $tickets, 'data' => ['tickets' => $tickets]]);
}

// -----------------------------------------------------------------------------
// 7. ADMIN ENDPOINTS (STRICT RBAC PROTECTED — REJECTS CUSTOMERS WITH HTTP 403)
// -----------------------------------------------------------------------------
if (str_starts_with($route, 'admin/')) {
    $admin = requireAdmin();

    // A. Admin Overview Stats
    if ($route === 'admin/overview' || $route === 'admin/reports/daily') {
        $totalUsers       = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role = 'customer'")->fetchColumn();
        $pendingOrders    = (int)$pdo->query("SELECT COUNT(*) FROM orders WHERE status = 'pending'")->fetchColumn();
        $pendingRecharges = (int)$pdo->query("SELECT COUNT(*) FROM recharge_requests WHERE status = 'pending'")->fetchColumn();
        $totalLiabilities = (float)($pdo->query("SELECT SUM(balance) FROM wallets")->fetchColumn() ?: 0.0);

        $stats = [
            'totalUsers'       => $totalUsers,
            'pendingOrders'    => $pendingOrders,
            'pendingRecharges' => $pendingRecharges,
            'totalLiabilities' => $totalLiabilities
        ];

        jsonResponse(['success' => true, 'stats' => $stats, 'data' => $stats]);
    }

    // B. Admin Users List & Management
    if ($route === 'admin/users/list' && $method === 'GET') {
        $stmt = $pdo->query("
            SELECT u.id, u.name, u.email, u.phone, u.role, u.status, u.created_at AS createdAt, COALESCE(w.balance, 0) AS walletBalance
            FROM users u
            LEFT JOIN wallets w ON u.id = w.user_id
            ORDER BY u.id DESC
        ");
        $rawUsers = $stmt->fetchAll();
        $usersList = [];
        foreach ($rawUsers as $u) {
            $usersList[] = [
                'id'            => (string)$u['id'],
                'name'          => (string)$u['name'],
                'email'         => (string)$u['email'],
                'phone'         => (string)$u['phone'],
                'role'          => (string)$u['role'],
                'status'        => (string)$u['status'],
                'createdAt'     => (string)$u['createdAt'],
                'walletBalance' => (float)$u['walletBalance'],
            ];
        }
        jsonResponse(['success' => true, 'users' => $usersList, 'data' => $usersList]);
    }

    if ($route === 'admin/users/update_status' && $method === 'POST') {
        validateCsrf($body);
        $userId = (int)($body['userId'] ?? 0);
        $status = in_array($body['status'] ?? '', ['active', 'suspended'], true) ? $body['status'] : 'active';
        $stmt = $pdo->prepare("UPDATE users SET status = ? WHERE id = ?");
        $stmt->execute([$status, $userId]);
        jsonResponse(['success' => true, 'message' => 'গ্রাহকের স্ট্যাটাস আপডেট করা হয়েছে']);
    }

    // C. Admin Orders List & Status Management
    if ($route === 'admin/orders/list' && $method === 'GET') {
        $stmt = $pdo->query("
            SELECT o.*, u.name AS userName, u.phone AS userPhone
            FROM orders o
            JOIN users u ON o.user_id = u.id
            ORDER BY o.id DESC
        ");
        $rows = $stmt->fetchAll();
        $ordersList = [];
        foreach ($rows as $o) {
            $ordersList[] = [
                'id'             => (string)$o['id'],
                'orderNumber'    => $o['order_number'],
                'userId'         => (string)$o['user_id'],
                'userName'       => $o['userName'],
                'userPhone'      => $o['userPhone'],
                'serviceId'      => (string)$o['service_id'],
                'serviceName'    => $o['service_name'],
                'servicePrice'   => (float)$o['service_price'],
                'formData'       => json_decode($o['form_values_json'] ?: '{}', true),
                'status'         => $o['status'],
                'adminNote'      => $o['admin_note'],
                'deliverableUrl' => $o['deliverable_file'] ? '/api/files?file=' . urlencode($o['deliverable_file']) : null,
                'createdAt'      => $o['created_at'],
                'updatedAt'      => $o['updated_at']
            ];
        }
        jsonResponse(['success' => true, 'orders' => $ordersList, 'data' => $ordersList]);
    }

    if (($route === 'admin/orders/update_status' || $route === 'admin/orders/refund') && $method === 'POST') {
        validateCsrf($body);
        $orderId   = (int)($body['orderId'] ?? 0);
        $newStatus = $route === 'admin/orders/refund' ? 'refunded' : sanitize((string)($body['status'] ?? ''));
        $adminNote = sanitize((string)($body['adminNote'] ?? $body['reason'] ?? ''));

        $allowedStatuses = ['pending', 'processing', 'needs_info', 'completed', 'rejected', 'cancelled', 'refunded'];
        if (!in_array($newStatus, $allowedStatuses, true)) {
            jsonResponse(['success' => false, 'message' => 'অবৈধ অর্ডার স্ট্যাটাস'], 400);
        }

        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ? FOR UPDATE");
            $stmt->execute([$orderId]);
            $order = $stmt->fetch();

            if (!$order) {
                $pdo->rollBack();
                jsonResponse(['success' => false, 'message' => 'অর্ডার পাওয়া যায়নি'], 404);
            }

            if ($newStatus === 'refunded' && $order['status'] !== 'refunded') {
                $price = (float)$order['service_price'];

                $stmtRef = $pdo->prepare("UPDATE wallets SET balance = balance + ? WHERE user_id = ?");
                $stmtRef->execute([$price, $order['user_id']]);

                $stmtBal = $pdo->prepare("SELECT balance FROM wallets WHERE user_id = ?");
                $stmtBal->execute([$order['user_id']]);
                $balAfter = (float)$stmtBal->fetchColumn();

                $stmtLed = $pdo->prepare("INSERT INTO wallet_ledger (user_id, amount, type, category, reference_id, description, balance_after) VALUES (?, ?, 'credit', 'refund', ?, ?, ?)");
                $desc = "Refund for {$order['service_name']} ({$order['order_number']})";
                $stmtLed->execute([$order['user_id'], $price, $order['order_number'], $desc, $balAfter]);
            }

            $stmtUpdate = $pdo->prepare("UPDATE orders SET status = ?, admin_note = ?, updated_at = NOW() WHERE id = ?");
            $stmtUpdate->execute([$newStatus, $adminNote, $orderId]);

            $pdo->commit();

            $statusLabels = [
                'pending'    => 'অপেক্ষমাণ',
                'processing' => 'প্রসেসিং চলছে',
                'needs_info' => 'আরও তথ্য প্রয়োজন',
                'completed'  => 'সম্পন্ন হয়েছে',
                'rejected'   => 'বাতিল করা হয়েছে',
                'cancelled'  => 'বাতিল হয়েছে',
                'refunded'   => 'রিফান্ড করা হয়েছে',
            ];
            $nType = $newStatus === 'completed' ? 'success'
                   : (in_array($newStatus, ['rejected', 'cancelled'], true) ? 'alert'
                   : (in_array($newStatus, ['needs_info', 'refunded'], true) ? 'warning' : 'info'));
            $nMsg = "অর্ডার {$order['order_number']} ({$order['service_name']}) — " . ($statusLabels[$newStatus] ?? $newStatus) . "।";
            if ($adminNote !== '') { $nMsg .= " বার্তা: {$adminNote}"; }
            createNotification($pdo, (int)$order['user_id'], $nType, 'অর্ডার আপডেট', $nMsg, '/orders');

            jsonResponse(['success' => true, 'message' => 'অর্ডারের স্ট্যাটাস সফলভাবে আপডেট হয়েছে।']);
        } catch (Exception $e) {
            $pdo->rollBack();
            error_log("Order update error: " . $e->getMessage());
            jsonResponse(['success' => false, 'message' => 'অর্ডার আপডেট করতে ব্যর্থ হয়েছে।'], 500);
        }
    }

    // D. Admin Recharges List, Approve & Reject
    if ($route === 'admin/recharges/list' && $method === 'GET') {
        $stmt = $pdo->query("
            SELECT r.id, r.user_id AS userId, u.name AS userName, u.phone AS userPhone, r.method, r.amount, r.sender_number AS senderNumber, r.trx_id AS trxId, r.status, r.rejection_reason AS rejectionReason, r.created_at AS createdAt, r.approved_at AS approvedAt
            FROM recharge_requests r
            JOIN users u ON r.user_id = u.id
            ORDER BY r.id DESC
        ");
        $rawList = $stmt->fetchAll();
        $list = [];
        foreach ($rawList as $r) {
            $list[] = [
                'id'              => (string)$r['id'],
                'userId'          => (string)$r['userId'],
                'userName'        => (string)$r['userName'],
                'userPhone'       => (string)$r['userPhone'],
                'method'          => $r['method'],
                'amount'          => (float)$r['amount'],
                'senderNumber'    => $r['senderNumber'],
                'trxId'           => $r['trxId'],
                'status'          => $r['status'],
                'rejectionReason' => $r['rejectionReason'],
                'createdAt'       => $r['createdAt'],
                'approvedAt'      => $r['approvedAt'],
            ];
        }
        jsonResponse(['success' => true, 'recharges' => $list, 'data' => $list]);
    }

    if ($route === 'admin/recharges/approve' && $method === 'POST') {
        validateCsrf($body);
        $requestId = (int)($body['rechargeId'] ?? $body['requestId'] ?? $body['request_id'] ?? 0);
        if ($requestId <= 0) {
            jsonResponse(['success' => false, 'message' => 'সঠিক রিচার্জ রিকোয়েস্ট আইডি পাওয়া যায়নি'], 400);
        }

        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare("SELECT * FROM recharge_requests WHERE id = ? FOR UPDATE");
            $stmt->execute([$requestId]);
            $req = $stmt->fetch();

            if (!$req) {
                $pdo->rollBack();
                jsonResponse(['success' => false, 'message' => 'রিকোয়েস্ট পাওয়া যায়নি'], 404);
            }
            if ($req['status'] === 'approved') {
                $pdo->rollBack();
                jsonResponse(['success' => false, 'message' => 'ইতিমধ্যেই অনুমোদিত হয়েছে'], 400);
            }

            $stmtUp = $pdo->prepare("UPDATE recharge_requests SET status = 'approved', rejection_reason = NULL, approved_at = NOW(), verified_by_admin_id = ? WHERE id = ?");
            $stmtUp->execute([$admin['id'], $requestId]);

            $stmtWal = $pdo->prepare("INSERT INTO wallets (user_id, balance) VALUES (?, ?) ON DUPLICATE KEY UPDATE balance = balance + ?");
            $stmtWal->execute([$req['user_id'], $req['amount'], $req['amount']]);

            $stmtGetBal = $pdo->prepare("SELECT balance FROM wallets WHERE user_id = ?");
            $stmtGetBal->execute([$req['user_id']]);
            $newBalance = (float)$stmtGetBal->fetchColumn();

            $stmtLed = $pdo->prepare("INSERT INTO wallet_ledger (user_id, amount, type, category, reference_id, description, balance_after) VALUES (?, ?, 'credit', 'recharge', ?, ?, ?)");
            $desc = "{$req['method']} Manual Recharge Approved (Trx: {$req['trx_id']})";
            $stmtLed->execute([$req['user_id'], $req['amount'], $req['trx_id'], $desc, $newBalance]);

            $pdo->commit();
        } catch (Exception $e) {
            if ($pdo->inTransaction()) { $pdo->rollBack(); }
            error_log("Recharge approve error: " . $e->getMessage());
            jsonResponse(['success' => false, 'message' => 'অনুমোদনে সমস্যা হয়েছে।'], 500);
        }

        // Notify the customer (after commit; never blocks the response)
        createNotification(
            $pdo, (int)$req['user_id'], 'success', 'রিচার্জ সফল হয়েছে',
            formatTaka((float)$req['amount']) . " আপনার ওয়ালেটে যুক্ত হয়েছে। বর্তমান ব্যালেন্স " . formatTaka($newBalance) . "। (TrxID: {$req['trx_id']})",
            '/wallet'
        );
        jsonResponse(['success' => true, 'message' => 'রিচার্জ সফলভাবে অনুমোদিত হয়েছে ও ব্যালেন্স যুক্ত হয়েছে।', 'new_balance' => $newBalance]);
    }

    if ($route === 'admin/recharges/reject' && $method === 'POST') {
        validateCsrf($body);
        $requestId = (int)($body['rechargeId'] ?? $body['requestId'] ?? $body['request_id'] ?? 0);
        $reason    = sanitize((string)($body['reason'] ?? ''));
        if ($reason === '') {
            $reason = 'ভুল TrxID বা পেমেন্ট পাওয়া যায়নি';
        }
        if ($requestId <= 0) {
            jsonResponse(['success' => false, 'message' => 'সঠিক রিচার্জ রিকোয়েস্ট আইডি পাওয়া যায়নি'], 400);
        }

        $stmt = $pdo->prepare("UPDATE recharge_requests SET status = 'rejected', rejection_reason = ?, verified_by_admin_id = ? WHERE id = ? AND status = 'pending'");
        $stmt->execute([$reason, $admin['id'], $requestId]);

        if ($stmt->rowCount() === 0) {
            jsonResponse(['success' => false, 'message' => 'রিকোয়েস্টটি পাওয়া যায়নি অথবা ইতিমধ্যে প্রসেস করা হয়েছে।'], 400);
        }

        $stmtR = $pdo->prepare("SELECT user_id, amount, trx_id FROM recharge_requests WHERE id = ?");
        $stmtR->execute([$requestId]);
        $reqRow = $stmtR->fetch();
        if ($reqRow) {
            createNotification(
                $pdo, (int)$reqRow['user_id'], 'alert', 'রিচার্জ রিকোয়েস্ট বাতিল হয়েছে',
                formatTaka((float)$reqRow['amount']) . " রিচার্জ বাতিল করা হয়েছে (TrxID: {$reqRow['trx_id']})। কারণ: {$reason}",
                '/recharges'
            );
        }
        jsonResponse(['success' => true, 'message' => 'রিচার্জ রিকোয়েস্ট বাতিল করা হয়েছে']);
    }

    // E. Admin Wallet Ledger & Manual Adjustment
    if ($route === 'admin/wallet/ledger' && $method === 'GET') {
        $stmt = $pdo->query("SELECT id, user_id AS userId, amount, type, category, reference_id AS referenceId, description, balance_after AS balanceAfter, created_at AS createdAt FROM wallet_ledger ORDER BY id DESC LIMIT 200");
        $rawList = $stmt->fetchAll();
        $list = [];
        foreach ($rawList as $l) {
            $list[] = [
                'id'           => (string)$l['id'],
                'userId'       => (string)$l['userId'],
                'amount'       => (float)$l['amount'],
                'type'         => $l['type'],
                'category'     => $l['category'],
                'referenceId'  => $l['referenceId'],
                'description'  => $l['description'],
                'balanceAfter' => (float)$l['balanceAfter'],
                'createdAt'    => $l['createdAt'],
            ];
        }
        jsonResponse(['success' => true, 'ledger' => $list, 'data' => $list]);
    }

    if ($route === 'admin/wallet/summary' && $method === 'GET') {
        $totalLiabilities = (float)($pdo->query("SELECT SUM(balance) FROM wallets")->fetchColumn() ?: 0.0);
        $totalCredits     = (float)($pdo->query("SELECT SUM(amount) FROM wallet_ledger WHERE type = 'credit'")->fetchColumn() ?: 0.0);
        $totalDebits      = (float)($pdo->query("SELECT SUM(amount) FROM wallet_ledger WHERE type = 'debit'")->fetchColumn() ?: 0.0);
        $data = [
            'totalLiabilities' => $totalLiabilities,
            'totalCredits'     => $totalCredits,
            'totalDebits'      => $totalDebits
        ];
        jsonResponse(['success' => true, 'data' => $data]);
    }

    if ($route === 'admin/wallet/adjust' && $method === 'POST') {
        validateCsrf($body);
        $userId = (int)($body['userId'] ?? 0);
        $reason = sanitize((string)($body['reason'] ?? ''));

        if ($reason === '') {
            jsonResponse(['success' => false, 'message' => 'অ্যাডজাস্টমেন্টের কারণ উল্লেখ করা আবশ্যক।'], 400);
        }

        $pdo->beginTransaction();
        try {
            $stmtWal = $pdo->prepare("SELECT balance FROM wallets WHERE user_id = ? FOR UPDATE");
            $stmtWal->execute([$userId]);
            $currentBalance = (float)($stmtWal->fetchColumn() ?: 0.0);

            if (isset($body['newBalance'])) {
                $targetBalance = (float)$body['newBalance'];
                $diff = $targetBalance - $currentBalance;
            } else {
                $adjType       = ($body['type'] ?? 'credit') === 'debit' ? 'debit' : 'credit';
                $adjAmount     = abs((float)($body['amount'] ?? 0));
                $diff          = $adjType === 'credit' ? $adjAmount : -$adjAmount;
                $targetBalance = $currentBalance + $diff;
            }

            if ($targetBalance < 0) {
                $pdo->rollBack();
                jsonResponse(['success' => false, 'message' => 'গ্রাহকের ব্যালেন্স ঋণাত্মক (Negative) করা যাবে না।'], 400);
            }

            if (abs($diff) < 0.01) {
                $pdo->rollBack();
                jsonResponse(['success' => false, 'message' => 'কোনো পরিবর্তন হয়নি।'], 400);
            }

            $stmtUp = $pdo->prepare("INSERT INTO wallets (user_id, balance) VALUES (?, ?) ON DUPLICATE KEY UPDATE balance = ?");
            $stmtUp->execute([$userId, $targetBalance, $targetBalance]);

            $type = $diff > 0 ? 'credit' : 'debit';
            $refId = 'ADJ-' . date('YmdHis');
            $stmtLed = $pdo->prepare("INSERT INTO wallet_ledger (user_id, amount, type, category, reference_id, description, balance_after) VALUES (?, ?, ?, 'adjustment', ?, ?, ?)");
            $desc = "Manual Adjustment by Admin ({$admin['name']}): {$reason}";
            $stmtLed->execute([$userId, abs($diff), $type, $refId, $desc, $targetBalance]);

            $pdo->commit();
            createNotification(
                $pdo, $userId, $diff > 0 ? 'success' : 'warning', 'ওয়ালেট ব্যালেন্স আপডেট',
                "আপনার ওয়ালেটে " . formatTaka(abs($diff)) . ($diff > 0 ? ' যুক্ত' : ' কর্তন') . " করা হয়েছে। বর্তমান ব্যালেন্স " . formatTaka($targetBalance) . "। কারণ: {$reason}",
                '/wallet'
            );
            jsonResponse(['success' => true, 'message' => 'ব্যালেন্স সফলভাবে সমন্বয় করা হয়েছে।', 'newBalance' => $targetBalance]);
        } catch (Exception $e) {
            $pdo->rollBack();
            error_log("Adjustment error: " . $e->getMessage());
            jsonResponse(['success' => false, 'message' => 'সমন্বয় করতে ব্যর্থ হয়েছে।'], 500);
        }
    }

    // F. Admin Services & Categories
    if ($route === 'admin/services/list' && $method === 'GET') {
        $stmt = $pdo->query("SELECT * FROM services ORDER BY id ASC");
        $list = $stmt->fetchAll();
        jsonResponse(['success' => true, 'services' => $list, 'data' => $list]);
    }

    if ($route === 'admin/services/categories' && $method === 'GET') {
        $stmt = $pdo->query("SELECT id, name, bangla_name AS banglaName, icon_name AS iconName, description FROM service_categories ORDER BY id ASC");
        $list = $stmt->fetchAll();
        jsonResponse(['success' => true, 'categories' => $list, 'data' => $list]);
    }

    // G. Admin Support Tickets
    if ($route === 'admin/support/list' && $method === 'GET') {
        $stmt = $pdo->query("
            SELECT t.id, t.ticket_number AS ticketNumber, t.user_id AS userId, u.name AS userName, t.subject, t.status, t.priority, t.created_at AS createdAt
            FROM support_tickets t
            JOIN users u ON t.user_id = u.id
            ORDER BY t.id DESC
        ");
        $list = $stmt->fetchAll();
        jsonResponse(['success' => true, 'tickets' => $list, 'data' => $list]);
    }

    // H. Admin Audit Logs
    if ($route === 'admin/security/audit_logs' && $method === 'GET') {
        $stmt = $pdo->query("SELECT id, admin_id AS adminId, admin_name AS adminName, action, target_type AS targetType, target_id AS targetId, old_value AS oldValue, new_value AS newValue, ip_address AS ip, created_at AS createdAt FROM admin_audit_logs ORDER BY id DESC LIMIT 200");
        $logs = $stmt->fetchAll();
        jsonResponse(['success' => true, 'logs' => $logs, 'data' => $logs]);
    }

    if ($route === 'admin/security/log_action' && $method === 'POST') {
        validateCsrf($body);
        $action     = sanitize((string)($body['action'] ?? 'ADMIN_ACTION'));
        $targetType = sanitize((string)($body['targetType'] ?? 'system'));
        $targetId   = sanitize((string)($body['targetId'] ?? '0'));
        $oldVal     = (string)($body['oldValue'] ?? '');
        $newVal     = (string)($body['newValue'] ?? '');
        $ip         = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
        $ua         = substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 250);

        $stmt = $pdo->prepare("INSERT INTO admin_audit_logs (admin_id, admin_name, action, target_type, target_id, old_value, new_value, ip_address, user_agent) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$admin['id'], $admin['name'], $action, $targetType, $targetId, $oldVal, $newVal, $ip, $ua]);
        jsonResponse(['success' => true]);
    }

    // I. Admin Settings
    if (str_starts_with($route, 'admin/settings')) {
        if ($method === 'GET') {
            $stmt = $pdo->query("SELECT setting_key, setting_value FROM site_settings");
            $kv = [];
            foreach ($stmt->fetchAll() as $row) {
                $kv[$row['setting_key']] = $row['setting_value'];
            }
            jsonResponse(['success' => true, 'settings' => $kv, 'data' => $kv]);
        }
        if ($method === 'POST') {
            validateCsrf($body);
            $stmt = $pdo->prepare("INSERT INTO site_settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)");
            foreach ($body as $k => $v) {
                if (is_scalar($v) && $k !== 'csrf_token') {
                    $stmt->execute([sanitize((string)$k), (string)$v]);
                }
            }
            jsonResponse(['success' => true, 'message' => 'সেটিংস সংরক্ষিত হয়েছে']);
        }
    }
}

// -----------------------------------------------------------------------------
// 8. FALLBACK / 404 NOT FOUND
// -----------------------------------------------------------------------------
jsonResponse(['success' => false, 'message' => "API রুট পাওয়া যায়নি ({$route})"], 404);
