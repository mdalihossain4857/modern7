<?php
/**
 * DigiSeba BD - Orders API (Atomic Wallet Debit & Status Management)
 * Location: htdocs/api/orders.php
 */

declare(strict_types=1);
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/security.php';

$pdo = getDbConnection();
$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

if ($method === 'POST' && $action === 'create') {
    $user = requireAuth();
    validateCsrf();
    $data = json_decode(file_get_contents('php://input'), true) ?: [];

    $serviceId = (int)($data['service_id'] ?? $data['serviceId'] ?? 0);
    $formValues = $data['form_values'] ?? $data['formData'] ?? [];

    $pdo->beginTransaction();
    try {
        $stmtSrv = $pdo->prepare("SELECT id, name, bangla_name, price, status FROM services WHERE id = ?");
        $stmtSrv->execute([$serviceId]);
        $srv = $stmtSrv->fetch();

        if (!$srv || $srv['status'] !== 'active') {
            $pdo->rollBack();
            jsonResponse(['success' => false, 'message' => 'সার্ভিসটি পাওয়া যায়নি বা বর্তমানে নিষ্ক্রিয় রয়েছে'], 404);
        }

        $price = (float)$srv['price'];

        $stmtWal = $pdo->prepare("SELECT balance FROM wallets WHERE user_id = ? FOR UPDATE");
        $stmtWal->execute([$user['id']]);
        $currentBalance = (float)($stmtWal->fetchColumn() ?: 0.0);

        if ($currentBalance < $price) {
            $pdo->rollBack();
            jsonResponse([
                'success' => false, 
                'message' => 'আপনার ওয়ালেটে পর্যাপ্ত ব্যালেন্স নেই।'
            ], 400);
        }

        $orderNumber = 'ORD-' . date('Y') . '-' . mt_rand(1000, 9999);
        $newBalance = $currentBalance - $price;

        $stmtDeduct = $pdo->prepare("UPDATE wallets SET balance = ? WHERE user_id = ?");
        $stmtDeduct->execute([$newBalance, $user['id']]);

        $stmtOrder = $pdo->prepare("INSERT INTO orders (order_number, user_id, service_id, service_name, service_price, form_values_json, status) VALUES (?, ?, ?, ?, ?, ?, 'pending')");
        $stmtOrder->execute([
            $orderNumber,
            $user['id'],
            $srv['id'],
            $srv['bangla_name'],
            $price,
            json_encode($formValues, JSON_UNESCAPED_UNICODE)
        ]);
        $orderId = (int)$pdo->lastInsertId();

        $stmtLedger = $pdo->prepare("INSERT INTO wallet_ledger (user_id, amount, type, category, reference_id, description, balance_after) VALUES (?, ?, 'debit', 'order', ?, ?, ?)");
        $desc = "Payment for {$srv['bangla_name']} ({$orderNumber})";
        $stmtLedger->execute([$user['id'], $price, $orderNumber, $desc, $newBalance]);

        $stmtInc = $pdo->prepare("UPDATE services SET order_count = order_count + 1 WHERE id = ?");
        $stmtInc->execute([$srv['id']]);

        $pdo->commit();
        jsonResponse([
            'success' => true,
            'message' => 'অর্ডার সফলভাবে জমা হয়েছে।',
            'order' => [
                'id' => (string)$orderId,
                'orderNumber' => $orderNumber,
                'balanceAfter' => $newBalance
            ]
        ]);
    } catch (Exception $e) {
        $pdo->rollBack();
        error_log("Order creation error: " . $e->getMessage());
        jsonResponse(['success' => false, 'message' => 'অর্ডার প্রক্রিয়াকরণ ব্যর্থ হয়েছে।'], 500);
    }
}
