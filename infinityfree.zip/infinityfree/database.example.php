<?php
/**
 * DigiSeba BD - Production Database Configuration Template
 * Target Hosting: InfinityFree PHP 8.x + MySQL
 * 
 * INSTRUCTIONS:
 * 1. Copy this file to `database.php` inside `/api/config/database.php`
 * 2. Replace the placeholder values below with your actual InfinityFree MySQL credentials from vPanel.
 * 3. NEVER commit or expose real credentials in public repositories or frontend assets.
 */

declare(strict_types=1);

// Disable error display in production to prevent credential/stack trace leakage
ini_set('display_errors', '0');
ini_set('log_errors', '1');

// InfinityFree MySQL Database Credentials (Replace with your vPanel values)
define('DB_HOST', getenv('DB_HOST') ?: 'YOUR_INFINITYFREE_MYSQL_HOST'); // e.g., sql205.infinityfree.com
define('DB_NAME', getenv('DB_NAME') ?: 'YOUR_DATABASE_NAME');           // e.g., if0_37000000_digiseba
define('DB_USER', getenv('DB_USER') ?: 'YOUR_DATABASE_USER');           // e.g., if0_37000000
define('DB_PASS', getenv('DB_PASS') ?: 'YOUR_DATABASE_PASSWORD');       // Your InfinityFree account password

/**
 * Returns a singleton PDO connection with UTF8mb4 and transaction support.
 */
function getDbConnection(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        if (DB_HOST === 'YOUR_INFINITYFREE_MYSQL_HOST' || DB_PASS === 'YOUR_DATABASE_PASSWORD') {
            http_response_code(503);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode([
                'success' => false,
                'message' => 'ডাটাবেজ কনফিগার করা হয়নি। অনুগ্রহ করে api/config/database.php ফাইলে আপনার InfinityFree MySQL তথ্য সেট করুন।'
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }

        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci"
        ];
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            error_log("Database connection failed: " . $e->getMessage());
            http_response_code(500);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode([
                'success' => false,
                'message' => 'ডাটাবেজ সংযোগে সমস্যা হয়েছে। অনুগ্রহ করে আপনার ডাটাবেজ ক্রেডেনশিয়াল যাচাই করুন।'
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }
    }
    return $pdo;
}
