<?php
/**
 * DigiSeba BD — Secure Database Configuration (InfinityFree Open_Basedir Safe)
 * Location: /database.config.php or htdocs/api/config/database.config.php
 */

declare(strict_types=1);

if (
    php_sapi_name() !== 'cli' &&
    isset($_SERVER['SCRIPT_FILENAME']) &&
    realpath((string)$_SERVER['SCRIPT_FILENAME']) === __FILE__
) {
    http_response_code(403);
    header('Content-Type: application/json; charset=utf-8');
    exit(json_encode(['success' => false, 'message' => 'Direct access forbidden.']));
}

if (!function_exists('loadDigiSebaEnv')) {
    function loadDigiSebaEnv(array $candidatePaths): void {
        foreach ($candidatePaths as $envFile) {
            if (@is_file($envFile) && @is_readable($envFile)) {
                $lines = @file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
                if (!is_array($lines)) {
                    continue;
                }
                foreach ($lines as $line) {
                    $trimmed = trim($line);
                    if ($trimmed === '' || str_starts_with($trimmed, '#') || !str_contains($trimmed, '=')) {
                        continue;
                    }
                    [$key, $val] = explode('=', $trimmed, 2);
                    $key = trim($key);
                    $val = trim(trim($val), "\"'");
                    if ($key !== '' && getenv($key) === false && !isset($_ENV[$key])) {
                        putenv("{$key}={$val}");
                        $_ENV[$key] = $val;
                        $_SERVER[$key] = $val;
                    }
                }
                break;
            }
        }
    }
}

$envPaths = [__DIR__ . '/.env'];
if (empty(ini_get('open_basedir'))) {
    $envPaths[] = dirname(__DIR__, 3) . '/.env';
}
loadDigiSebaEnv($envPaths);

if (!function_exists('envCredential')) {
    function envCredential(string $key, string $default = ''): string {
        $value = $_ENV[$key] ?? $_SERVER[$key] ?? getenv($key);
        if (is_string($value) && trim($value) !== '') {
            return trim($value);
        }
        return $default;
    }
}

return [
    'driver'    => 'mysql',
    'host'      => envCredential('DB_HOST', 'YOUR_INFINITYFREE_MYSQL_HOST'),
    'port'      => (int)envCredential('DB_PORT', '3306'),
    'database'  => envCredential('DB_NAME', 'YOUR_DATABASE_NAME'),
    'username'  => envCredential('DB_USER', 'YOUR_DATABASE_USER'),
    'password'  => envCredential('DB_PASS', 'YOUR_DATABASE_PASSWORD'),
    'charset'   => envCredential('DB_CHARSET', 'utf8mb4'),
    'collation' => envCredential('DB_COLLATION', 'utf8mb4_unicode_ci'),
    'options'   => [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
        PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci',
    ],
];
